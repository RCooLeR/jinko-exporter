const fe = {
  pv_total_power: { names: ["Total Solar Power", "Solar"] },
  pv_daily_energy: { names: ["PV daily power generation (active)", "Daily Production (Active)"] },
  pv1_voltage: { names: ["DC Voltage PV1"] },
  pv1_current: { names: ["DC Current PV1"] },
  pv1_power: { names: ["DC Power PV1"] },
  pv2_voltage: { names: ["DC Voltage PV2"] },
  pv2_current: { names: ["DC Current PV2"] },
  pv2_power: { names: ["DC Power PV2"] },
  grid_total_power: { names: ["Total Grid Power", "Internal Power"] },
  grid_frequency: { names: ["Grid Frequency"] },
  grid_buy_today: { names: ["Daily Energy Buy"] },
  grid_sell_today: { names: ["Daily energy sell"] },
  grid_l1_voltage: { names: ["Grid Voltage L1"] },
  grid_l2_voltage: { names: ["Grid Voltage L2"] },
  grid_l3_voltage: { names: ["Grid Voltage L3"] },
  grid_l1_current: { names: ["Grid Current L1"] },
  grid_l2_current: { names: ["Grid Current L2"] },
  grid_l3_current: { names: ["Grid Current L3"] },
  grid_l1_power: { names: ["Grid Power L1"] },
  grid_l2_power: { names: ["Grid Power L2"] },
  grid_l3_power: { names: ["Grid Power L3"] },
  home_total_power: { names: ["Total Consumption Power"] },
  home_daily_energy: { names: ["Daily Consumption"] },
  home_frequency: { names: ["Load Fequency", "Load Frequency"] },
  home_l1_voltage: { names: ["Load Voltage L1"] },
  home_l2_voltage: { names: ["Load Voltage L2"] },
  home_l3_voltage: { names: ["Load Voltage L3"] },
  home_l1_power: { names: ["Load Power L1", "Load phase power A"] },
  home_l2_power: { names: ["Load Power L2", "Load phase power B"] },
  home_l3_power: { names: ["Load Power L3", "Load phase power C"] },
  ups_total_power: { names: ["UPS Load Power"] },
  generator_daily_energy: { names: ["Daily Production Generator"] },
  generator_total_power: { names: ["Total Gen Power", "Generator Active Power"] },
  generator_l1_power: { names: ["Gen Power L1"] },
  generator_l2_power: { names: ["Gen Power L2"] },
  generator_l3_power: { names: ["Gen Power L3"] },
  generator_l1_voltage: { names: ["Gen Voltage L1"] },
  generator_l2_voltage: { names: ["Gen Voltage L2"] },
  generator_l3_voltage: { names: ["Gen Voltage L3"] },
  generator_daily_runtime: { names: ["Gen Daily Run Time"] },
  battery_voltage: { names: ["Battery Voltage"] },
  battery_current: { names: ["Battery Current"] },
  battery_power: { names: ["Battery Power"] },
  battery_soc: { names: ["SoC", "BMS_SOC"] },
  battery_temp: { names: ["Temperature- Battery", "BMS Temperature"] },
  battery_charge_today: { names: ["Daily Charging Energy"] },
  battery_discharge_today: { names: ["Daily Discharging Energy"] },
  inverter_total_power: { names: ["Total Inverter Output Power"] },
  inverter_l1_power: { names: ["Inverter Output Power L1"] },
  inverter_l2_power: { names: ["Inverter Output Power L2"] },
  inverter_l3_power: { names: ["Inverter Output Power L3"] },
  inverter_dc_power: { names: ["DC Input Power", "Total DC Power"] },
  inverter_l1_voltage: { names: ["AC Voltage R/U/A"] },
  inverter_l2_voltage: { names: ["AC Voltage S/V/B"] },
  inverter_l3_voltage: { names: ["AC Voltage T/W/C"] },
  inverter_l1_current: { names: ["AC Current R/U/A"] },
  inverter_l2_current: { names: ["AC Current S/V/B"] },
  inverter_l3_current: { names: ["AC Current T/W/C"] },
  inverter_frequency: { names: ["AC Output Frequency R"] },
  ac_temperature: { names: ["AC Temperature"] },
  power_factor: { names: ["Power factor"] },
  dc_bus_voltage: { names: ["Bus-N Voltage", "DC Bus Voltage", "DC bus", "HV Voltage"] },
  dc_temperature: { names: ["DC Temperature"] }
}, ie = Object.keys(fe), te = (t) => String(t ?? "").toLowerCase().replace(/_/g, " ").replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim(), qe = (t) => {
  if (!t) return null;
  const r = Number.parseFloat(t.state);
  return Number.isFinite(r) ? r : null;
}, Pe = (t, r = {}, e = ie) => {
  const o = {};
  if (!t) return o;
  for (const n of e)
    o[n] = Se(t, n, r[n]);
  return o;
}, Se = (t, r, e) => {
  if (e && t.states[e]) return e;
  const o = fe[r];
  let n = null;
  for (const [l, d] of Object.entries(t.states)) {
    if (!l.startsWith("sensor.")) continue;
    const m = te(d.attributes?.friendly_name), y = te(l);
    let g = 0;
    for (const [h, Q] of o.names.entries()) {
      const M = te(Q);
      M && (m === M ? g = Math.max(g, 300 - h) : m.includes(M) && (g = Math.max(g, 180 - h)), y.includes(M) && (g = Math.max(g, 120 - h)));
    }
    g > 0 && (!n || g > n.score) && (n = { entityId: l, score: g });
  }
  return n?.entityId ?? null;
}, Xe = (t, r, e) => {
  const o = r[e];
  return o ? qe(t?.states[o]) : null;
}, De = 28.74, Fe = 7380, Ae = 372, je = 11.2, Ze = 4160, Te = 365, Oe = 10.4, Re = 3220, Ie = 1210, Ne = 50, Ge = 4.82, Be = 12.36, We = 231, Ue = 232, Ke = 233, Je = 6.1, Ye = 5.8, er = 6, rr = 400, tr = 390, ar = 420, or = 8030, ir = 16.38, nr = 231, lr = 232, sr = 233, dr = 1860, pr = 1880, cr = 1880, gr = 5620, mr = 0, ur = 0, fr = 0, wr = 0, br = 0, hr = 0, yr = 0, vr = 0, xr = 52.6, _r = -38.6, Qr = -2030, $r = 82, Lr = 27.8, zr = 5.4, kr = 3.37, Vr = 5620, Hr = 6380, Cr = 231, Mr = 232, Er = 233, qr = 8.2, Pr = 8, Sr = 7.9, Xr = 50, Dr = 39.6, Fr = 388, Ar = 42.3, jr = 62.45, Zr = {
  pv_daily_energy: De,
  pv_total_power: Fe,
  pv1_voltage: Ae,
  pv1_current: je,
  pv1_power: Ze,
  pv2_voltage: Te,
  pv2_current: Oe,
  pv2_power: Re,
  grid_total_power: Ie,
  grid_frequency: Ne,
  grid_buy_today: Ge,
  grid_sell_today: Be,
  grid_l1_voltage: We,
  grid_l2_voltage: Ue,
  grid_l3_voltage: Ke,
  grid_l1_current: Je,
  grid_l2_current: Ye,
  grid_l3_current: er,
  grid_l1_power: rr,
  grid_l2_power: tr,
  grid_l3_power: ar,
  home_total_power: or,
  home_daily_energy: ir,
  home_l1_voltage: nr,
  home_l2_voltage: lr,
  home_l3_voltage: sr,
  home_l1_power: dr,
  home_l2_power: pr,
  home_l3_power: cr,
  ups_total_power: gr,
  generator_total_power: mr,
  generator_daily_energy: ur,
  generator_l1_voltage: fr,
  generator_l2_voltage: wr,
  generator_l3_voltage: br,
  generator_l1_power: hr,
  generator_l2_power: yr,
  generator_l3_power: vr,
  battery_voltage: xr,
  battery_current: _r,
  battery_power: Qr,
  battery_soc: $r,
  battery_temp: Lr,
  battery_charge_today: zr,
  battery_discharge_today: kr,
  inverter_total_power: Vr,
  inverter_dc_power: Hr,
  inverter_l1_voltage: Cr,
  inverter_l2_voltage: Mr,
  inverter_l3_voltage: Er,
  inverter_l1_current: qr,
  inverter_l2_current: Pr,
  inverter_l3_current: Sr,
  inverter_frequency: Xr,
  ac_temperature: Dr,
  dc_bus_voltage: Fr,
  dc_temperature: Ar,
  daily_cost: jr
}, s = (t) => Number.isFinite(t), F = (t) => {
  const r = t.filter(s);
  return r.length ? r.reduce((e, o) => e + o, 0) : null;
}, G = (t) => {
  const r = t.filter((e) => s(e) && e !== 0);
  return r.length ? r.reduce((e, o) => e + o, 0) / r.length : null;
}, S = (...t) => t.find((r) => r != null) ?? null, z = (t, r = 1) => Number.isFinite(t) ? t.toFixed(r).replace(/\.0+$|(\.\d*[1-9])0+$/, "$1") : "--", Tr = (t) => {
  const r = t.match(/^([+-]?(?:\d+(?:\.\d+)?|--))(?:\s+(.+))?$/);
  return r ? { value: r[1] ?? t, unit: r[2] ?? "" } : { value: t, unit: "" };
}, b = 1, X = 1, ne = 0.01, Or = [
  "pv1_power",
  "pv2_power",
  "grid_total_power",
  "home_total_power",
  "ups_total_power",
  "battery_power",
  "battery_soc"
], Rr = (t) => {
  const r = Zr;
  return s(r[t]) ? r[t] : null;
}, Ir = (t, r) => {
  const e = t, o = [1, 2, 3].map((i) => ({
    voltage: e(`grid_l${i}_voltage`),
    current: e(`grid_l${i}_current`),
    power: e(`grid_l${i}_power`)
  })), n = [1, 2, 3].map((i) => ({
    voltage: e(`home_l${i}_voltage`),
    power: e(`home_l${i}_power`)
  })), l = [1, 2, 3].map((i) => ({
    voltage: e(`inverter_l${i}_voltage`),
    current: e(`inverter_l${i}_current`),
    power: e(`inverter_l${i}_power`)
  })), d = [1, 2, 3].map((i) => ({
    voltage: e(`generator_l${i}_voltage`),
    power: e(`generator_l${i}_power`)
  })), m = e("pv1_power"), y = e("pv2_power"), g = S(e("pv_total_power"), F([m, y])), h = S(e("grid_total_power"), F(o.map((i) => i.power))), Q = G(o.map((i) => i.voltage)), M = F(n.map((i) => i.power)), P = S(e("home_total_power"), M), V = e("ups_total_power"), E = s(P) && s(V) ? Math.max(P - V, 0) : null, I = Br(E), J = o.map((i, Ee) => ({
    voltage: i.voltage,
    power: I[Ee] ?? null
  })), N = S(e("generator_total_power"), F(d.map((i) => i.power))), H = e("battery_power"), u = e("battery_soc"), D = S(e("inverter_total_power"), V, F(l.map((i) => i.power))), le = g, se = S(e("daily_cost"), Nr(e("grid_buy_today"), e("grid_sell_today"))), ve = r.now ?? /* @__PURE__ */ new Date(), Y = s(H) && Math.abs(H) >= b ? r.batteryNegativeIsCharging ? H < 0 : H > 0 : !1, xe = s(H) && Math.abs(H) >= b ? Y ? "Заряд" : "Розряд" : "Очікування", ee = c(m, b), re = c(y, b), _e = s(h) && h > b, Qe = s(h) && h < -b, $e = c(h, b) && c(Q, X), Le = c(H, b), ze = c(N, b), ke = c(V, b), Ve = c(E, b), He = {
    "daily.production.value": q(e("pv_daily_energy")).value,
    "daily.production.unit": q(e("pv_daily_energy")).unit,
    "daily.export.value": q(e("grid_sell_today")).value,
    "daily.export.unit": q(e("grid_sell_today")).unit,
    "daily.import.value": q(e("grid_buy_today")).value,
    "daily.import.unit": q(e("grid_buy_today")).unit,
    "daily.generator.value": q(e("generator_daily_energy")).value,
    "daily.generator.unit": q(e("generator_daily_energy")).unit,
    "daily.cost.value": de(se).value,
    "daily.cost.unit": de(se).unit,
    "status.grid": `Робота від
мережі`,
    "status.solar": `Робота від
сонця`,
    "status.battery": "Заряд АКБ",
    "status.generator": `Генератор
standby`,
    "pv.total.power": pe(g),
    "pv.total.power.value": p(g).value,
    "pv.total.power.unit": p(g).unit,
    "pv1.voltage": T(e("pv1_voltage")),
    "pv1.current": K(e("pv1_current")),
    "pv1.power.value": p(m).value,
    "pv1.power.unit": p(m).unit,
    "pv2.voltage": T(e("pv2_voltage")),
    "pv2.current": K(e("pv2_current")),
    "pv2.power.value": p(y).value,
    "pv2.power.unit": p(y).unit,
    "grid.phases": A(o.map((i) => i.voltage), Q),
    "grid.current": j(o.map((i) => i.current), null),
    "grid.phase_power": W(o.map((i) => i.power)),
    "grid.power.value": p(h).value,
    "grid.power.unit": p(h).unit,
    "grid.status": s(h) && h < 0 ? "Експорт в мережу" : "Імпорт з мережі",
    "grid_load.phases": A(o.map((i) => i.voltage), Q),
    "grid_load.current": j(ae(J), null),
    "grid_load.power.value": p(E).value,
    "grid_load.power.unit": p(E).unit,
    "grid_load.phase_power": W(I),
    "load.total_power.value": p(P).value,
    "load.total_power.unit": p(P).unit,
    "ups.phases": A(n.map((i) => i.voltage), G(n.map((i) => i.voltage))),
    "ups.current": j(ae(n), null),
    "ups.power.value": p(V).value,
    "ups.power.unit": p(V).unit,
    "ups.phase_power": W(n.map((i) => i.power)),
    "inverter.ac_power.value": p(D).value,
    "inverter.ac_power.unit": p(D).unit,
    "inverter.dc_power.value": p(le).value,
    "inverter.dc_power.unit": p(le).unit,
    "inverter.output_power": pe(D),
    "inverter.output_power.value": p(D).value,
    "inverter.output_power.unit": p(D).unit,
    "inverter.ac_temperature": B(e("ac_temperature")),
    "inverter.dc_temperature": B(e("dc_temperature")),
    "inverter.ac_temperature_compact": ce(e("ac_temperature")),
    "inverter.dc_temperature_compact": ce(e("dc_temperature")),
    "inverter.phases": A(l.map((i) => i.voltage), G(l.map((i) => i.voltage))),
    "inverter.current": j(l.map((i) => i.current), null),
    "inverter.frequency": ge(e("inverter_frequency")),
    "inverter.temperature": B(S(e("dc_temperature"), e("ac_temperature"))),
    "inverter.status": "Нормально",
    "battery.soc.value": Gr(u).value,
    "battery.soc.unit": "%",
    "battery.voltage": T(e("battery_voltage")),
    "battery.current": K(e("battery_current"), !0),
    "battery.power.value": p(H).value,
    "battery.power.unit": p(H).unit,
    "battery.mode": `(${xe})`,
    "battery.temperature": B(e("battery_temp")),
    "generator.phases": A(d.map((i) => i.voltage), G(d.map((i) => i.voltage))),
    "generator.current": j(ae(d), null),
    "generator.power.value": p(N).value,
    "generator.power.unit": p(N).unit,
    "generator.phase_power": W(d.map((i) => i.power)),
    "generator.status": "standby",
    "system.online": "Онлайн",
    "system.frequency": ge(e("grid_frequency")),
    "system.dc_bus": T(e("dc_bus_voltage")),
    "system.generation": Z(e("pv_daily_energy")),
    "system.self_consumption": Z(e("home_daily_energy")),
    "system.export": Z(e("grid_sell_today")),
    "system.import": Z(e("grid_buy_today")),
    "system.updated_at": ve.toLocaleTimeString("uk-UA", { hour: "2-digit", minute: "2-digit", second: "2-digit" })
  }, Ce = {
    online: !0,
    pv1_offline: !ee && !c(e("pv1_voltage"), X),
    pv2_offline: !re && !c(e("pv2_voltage"), X),
    pv_offline: !c(g, b),
    grid_offline: !c(h, b) && !c(Q, X),
    battery_offline: !c(u, ne) && !c(H, b),
    generator_offline: !c(N, b),
    ups_offline: !c(V, b),
    grid_load_offline: !c(E, b),
    battery_charging: Y,
    battery_empty: s(u) && u <= 10,
    battery_low: s(u) && u > 10 && u <= 35,
    battery_half: s(u) && u > 35 && u <= 75,
    battery_full: !s(u) || u > 75,
    battery_q1: s(u) && u > 0,
    battery_q2: s(u) && u >= 25,
    battery_q3: s(u) && u >= 50,
    battery_q4: s(u) && u >= 75,
    flow_pv1_inverter_active: ee,
    flow_pv2_inverter_active: re,
    flow_pv_inverter_active: ee || re,
    flow_battery_inverter_active: Le,
    flow_battery_inverter_reverse: Y,
    flow_inverter_grid_active: $e,
    flow_inverter_grid_reverse: _e,
    flow_inverter_grid_forward: Qe,
    flow_generator_inverter_active: ze,
    flow_inverter_ups_active: ke,
    flow_inverter_load_active: c(P, b),
    flow_grid_load_active: Ve
  }, Me = Or.filter((i) => e(i) === null);
  return { values: He, flags: Ce, missing: Me };
}, Nr = (t, r) => {
  if (!s(t) && !s(r)) return null;
  const e = t ?? 0, o = r ?? 0;
  return o > e ? (o - e) * 6.515 : -((e - o) * 4.32);
}, c = (t, r) => s(t) && Math.abs(t) >= r, Z = (t) => s(t) ? `${z(t, 2)} kWh` : "--", q = (t) => Tr(Z(t)), de = (t) => s(t) ? { value: z(Math.abs(t), 2), unit: "грн" } : { value: "--", unit: "" }, Gr = (t) => s(t) ? { value: z(t, t >= 10 ? 0 : 1), unit: "%" } : { value: "--", unit: "" }, pe = (t, r = !1) => {
  const e = p(t, r);
  return e.unit ? `${e.value} ${e.unit}` : e.value;
}, p = (t, r = !1) => {
  if (!s(t)) return { value: "--", unit: "" };
  const e = r && t > 0 ? "+" : t < 0 ? "-" : "", o = Math.abs(t);
  return o >= 1e3 ? { value: `${e}${z(o / 1e3, o >= 1e4 ? 1 : 2)}`, unit: "kW" } : { value: `${e}${z(o, o >= 100 ? 0 : 1)}`, unit: "W" };
}, T = (t) => s(t) ? `${z(t, t >= 100 ? 0 : 1)} V` : "--", K = (t, r = !1) => s(t) ? `${r && t > 0 ? "+" : t < 0 ? "-" : ""}${z(Math.abs(t), Math.abs(t) >= 10 ? 1 : 2)} A` : "--", B = (t) => s(t) ? `${z(t, 1)} °C` : "--", ce = (t) => s(t) ? `${z(t, 0)}°C` : "--", ge = (t) => s(t) ? `${z(t, 1)} Hz` : "--", A = (t, r) => t.some((e) => c(e, X)) ? `${t.map((e) => c(e, X) ? `${z(e, 0)}V` : "--").join(" / ")}` : T(r), j = (t, r) => t.some((e) => c(e, ne)) ? `${t.map((e) => c(e, ne) ? `${Number(e).toFixed(1)} A` : "--").join(" / ")}` : K(r), W = (t) => t.some((r) => c(r, b)) ? t.map((r) => c(r, b) ? `${z(Math.abs(r) / 1e3, 2)} kW` : "--").join(" / ") : "--", Br = (t) => {
  if (!s(t)) return [null, null, null];
  const r = t / 3;
  return [r * 0.98, r * 1.01, r * 1.01];
}, ae = (t) => t.map(
  (r) => s(r.voltage) && r.voltage !== 0 && s(r.power) ? Math.abs(r.power) / r.voltage : null
), $ = (t, r = "0 0 24 24") => `<svg viewBox="${r}" aria-hidden="true" focusable="false">${t}</svg>`, f = 'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"', k = (t, r) => $(`<g transform="translate(0 448) scale(1 -1)"><path d="${r}" fill="currentColor"/></g>`, `0 0 ${t} 512`), we = (t) => {
  switch (t) {
    case "arrowDown":
      return $(`<path ${f} d="M12 4v15M6 13l6 6 6-6"/>`);
    case "arrowUpRight":
      return $(`<path ${f} d="M7 17 17 7M9 7h8v8"/>`);
    case "battery":
    case "batteryFull":
      return k(576, "M464 288Q479 287 480 272V112Q479 97 464 96H80Q65 97 64 112V272Q65 287 80 288H464ZM80 352Q46 351 23 329Q1 306 0 272V112Q1 78 23 55Q46 33 80 32H464Q498 33 521 55Q543 78 544 112V128Q558 128 567 137Q576 146 576 160V224Q576 238 567 247Q558 256 544 256V272Q543 306 521 329Q498 351 464 352H80ZM448 256H96H448H96V128H448V256Z");
    case "batteryBolt":
      return k(576, "M80 352Q46 351 23 329Q1 306 0 272V112Q1 78 23 55Q46 33 80 32H172Q152 56 165 85L170 96H80Q65 97 64 112V272Q65 287 80 288H219L299 352H80ZM464 96H325H464H325L245 32H464Q498 33 521 55Q543 78 544 112V128Q558 128 567 137Q576 146 576 160V224Q576 238 567 247Q558 256 544 256V272Q543 306 521 329Q498 351 464 352H372Q392 328 379 298L374 288H464Q479 287 480 272V112Q479 97 464 96ZM346 332Q336 339 326 332L166 204Q158 197 161 187Q165 177 176 176H246L194 71Q189 60 198 52Q208 45 218 51L378 179Q386 187 383 197Q379 207 368 208H298L350 313Q355 324 346 332Z");
    case "batteryEmpty":
      return k(576, "M80 288Q65 287 64 272V112Q65 97 80 96H464Q479 97 480 112V272Q479 287 464 288H80ZM0 272Q1 306 23 329Q46 351 80 352H464Q498 351 521 329Q543 306 544 272V256Q558 256 567 247Q576 238 576 224V160Q576 146 567 137Q558 128 544 128V112Q543 78 521 55Q498 33 464 32H80Q46 33 23 55Q1 78 0 112V272Z");
    case "batteryLow":
      return k(576, "M464 288Q479 287 480 272V112Q479 97 464 96H80Q65 97 64 112V272Q65 287 80 288H464ZM80 352Q46 351 23 329Q1 306 0 272V112Q1 78 23 55Q46 33 80 32H464Q498 33 521 55Q543 78 544 112V128Q558 128 567 137Q576 146 576 160V224Q576 238 567 247Q558 256 544 256V272Q543 306 521 329Q498 351 464 352H80ZM160 256H96H160H96V128H160V256Z");
    case "batteryHalf":
      return k(576, "M464 288Q479 287 480 272V112Q479 97 464 96H80Q65 97 64 112V272Q65 287 80 288H464ZM80 352Q46 351 23 329Q1 306 0 272V112Q1 78 23 55Q46 33 80 32H464Q498 33 521 55Q543 78 544 112V128Q558 128 567 137Q576 146 576 160V224Q576 238 567 247Q558 256 544 256V272Q543 306 521 329Q498 351 464 352H80ZM288 256H96H288H96V128H288V256Z");
    case "cart":
      return $(`<path ${f} d="M4 5h2l2.2 9.2a2 2 0 0 0 2 1.6h5.9a2 2 0 0 0 1.9-1.4L20 8H7"/><circle cx="10" cy="19" r="1.4" fill="currentColor"/><circle cx="17" cy="19" r="1.4" fill="currentColor"/>`);
    case "clock":
      return $(`<circle ${f} cx="12" cy="12" r="8.5"/><path ${f} d="M12 7v5l3.5 2"/>`);
    case "generator":
      return $(`<rect ${f} x="4" y="8" width="16" height="9" rx="2"/><path ${f} d="M8 8V5h8v3M7 17v2M17 17v2M8 12h3M8 14h3M14 11.5h3v3h-3z"/>`);
    case "grid":
    case "utilityPole":
      return k(512, "M256 448Q270 448 279 439Q288 430 288 416V384H384V392Q386 414 408 416Q430 414 432 392V384H464V392Q466 414 488 416Q510 414 512 392V352Q512 338 503 329Q494 320 480 320H429L288 226V160V-32Q288 -46 279 -55Q270 -64 256 -64Q242 -64 233 -55Q224 -46 224 -32V160V226L83 320H32Q18 320 9 329Q0 338 0 352V392Q2 414 24 416Q46 414 48 392V384H80V392Q82 414 104 416Q126 414 128 392V384H224V416Q224 430 233 439Q242 448 256 448ZM141 320 224 265 141 320 224 265V320H141ZM288 265 371 320 288 265 371 320H288V265Z");
    case "home":
      return k(576, "M576 192Q575 179 566 170Q557 161 544 160H512L513 0Q512 -4 512 -8V-24Q512 -41 500 -52Q489 -64 472 -64H456Q454 -64 453 -64Q451 -64 449 -64H416H392Q375 -64 364 -52Q352 -41 352 -24V0V64Q352 78 343 87Q334 96 320 96H256Q242 96 233 87Q224 78 224 64V0V-24Q224 -41 212 -52Q201 -64 184 -64H160H128Q127 -64 126 -64Q125 -64 124 -64Q122 -64 120 -64H104Q87 -64 76 -52Q64 -41 64 -24V88Q64 89 64 91V160H32Q18 161 9 170Q0 179 0 193Q0 206 10 217L266 440Q277 449 288 448Q300 448 309 441L565 216Q577 206 576 192Z");
    case "homeDay":
      return k(640, "M174 440Q169 448 160 448Q151 448 146 440L118 388L63 405Q54 407 47 401Q40 394 43 385L60 329L8 302Q0 297 0 288Q0 278 8 274L60 246L43 190Q40 181 47 174Q54 168 63 170L118 187L133 160L191 213Q176 207 160 207Q126 208 103 230Q81 253 80 287Q81 321 103 344Q126 366 160 367Q194 366 217 344Q239 321 240 287Q240 267 231 251L296 310L261 329L277 385Q280 394 273 401Q267 408 258 405L202 388L174 440ZM112 288Q113 315 136 330Q160 342 184 330Q207 315 208 288Q207 261 184 246Q160 234 136 246Q113 261 112 288ZM422 343Q412 352 400 352Q388 352 378 343L170 151Q155 136 162 116Q171 97 192 96H224V-16Q225 -36 238 -50Q252 -63 272 -64H528Q548 -63 562 -50Q575 -36 576 -16V96H608Q629 97 638 116Q645 136 630 151L422 343ZM352 144Q353 159 368 160H432Q447 159 448 144V80Q447 65 432 64H368Q353 65 352 80V144Z");
    case "inverter":
      return k(384, "M136 424V416V424V416H160Q175 415 176 400Q175 385 160 384H112H64Q49 385 48 400Q49 415 64 416H88V424Q90 446 112 448Q134 446 136 424ZM296 424V416V424V416H320Q335 415 336 400Q335 385 320 384H272H224Q209 385 208 400Q209 415 224 416H248V424Q250 446 272 448Q294 446 296 424ZM48 336Q49 351 64 352H160Q175 351 176 336Q175 321 160 320H64Q49 321 48 336ZM208 336Q209 351 224 352H320Q335 351 336 336Q335 321 320 320H224Q209 321 208 336ZM0 256Q0 270 9 279Q18 288 32 288H352Q366 288 375 279Q384 270 384 256Q384 242 375 233Q366 224 352 224V0Q366 0 375 -9Q384 -18 384 -32Q384 -46 375 -55Q366 -64 352 -64H32Q18 -64 9 -55Q0 -46 0 -32Q0 -18 9 -9Q18 0 32 0V224Q18 224 9 233Q0 242 0 256ZM233 221Q223 227 214 220L102 124Q94 117 97 106Q101 97 112 96H170L145 21Q142 10 151 3Q161 -3 170 4L282 100Q290 107 287 118Q283 128 272 128H214L239 203Q242 214 233 221Z");
    case "load":
      return k(576, "M96 448Q82 448 73 439Q64 430 64 416V320H128V416Q128 430 119 439Q110 448 96 448ZM288 448Q274 448 265 439Q256 430 256 416V320H320V416Q320 430 311 439Q302 448 288 448ZM32 288Q18 288 9 279Q0 270 0 256Q0 242 9 233Q18 224 32 224V192Q33 133 69 90Q104 47 160 35V-32Q160 -46 169 -55Q178 -64 192 -64Q206 -64 215 -55Q224 -46 224 -32V35Q243 39 259 47Q256 63 256 80Q257 141 292 187Q327 232 383 249Q384 253 384 256Q384 270 375 279Q366 288 352 288H32ZM432 -64Q471 -64 504 -45Q537 -26 557 8Q576 42 576 80Q576 118 557 152Q537 186 504 205Q471 224 432 224Q393 224 360 205Q327 186 307 152Q288 118 288 80Q288 42 307 8Q327 -26 360 -45Q393 -64 432 -64ZM480 161Q487 155 483 146L452 92H488Q496 92 499 84Q502 76 495 70L399 -2Q392 -7 384 -1Q377 6 381 14L412 68H376Q368 68 365 76Q362 84 369 90L465 162Q472 167 480 161Z");
    case "shield":
      return $(`<path ${f} d="M12 3 5.5 5.8v5.5c0 4.2 2.6 7.7 6.5 9.7 3.9-2 6.5-5.5 6.5-9.7V5.8L12 3Z"/><path ${f} d="m9 12 2 2 4-5"/>`);
    case "solarPanel":
      return k(640, "M122 448Q99 448 82 434Q64 419 60 397L8 141Q3 110 22 87Q40 65 71 64H288V0H224Q210 0 201 -9Q192 -18 192 -32Q192 -46 201 -55Q210 -64 224 -64H416Q430 -64 439 -55Q448 -46 448 -32Q448 -18 439 -9Q430 0 416 0H352V64H569Q600 65 619 87Q637 110 632 141L581 397Q576 419 558 434Q541 448 518 448H122ZM261 384H379H261H379L389 280H250L261 384ZM202 280H102H202H102L122 384H213L202 280ZM92 232H197H92H197L187 128H71L92 232ZM246 232H394H246H394L405 128H235L246 232ZM443 232H548H443H548L569 128H453L443 232ZM539 280H438H539H438L427 384H518L549 390L518 384L539 280Z");
    case "sun":
      return $(`<circle ${f} cx="12" cy="12" r="4"/><path ${f} d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1"/>`);
    case "sync":
      return $(`<path ${f} d="M20 7v5h-5"/><path ${f} d="M4 17v-5h5"/><path ${f} d="M18.2 12A6.5 6.5 0 0 0 7 7.4L4 10.5"/><path ${f} d="M5.8 12A6.5 6.5 0 0 0 17 16.6l3-3.1"/>`);
    case "thermometer":
      return $(`<path ${f} d="M14 14.8V5a2 2 0 0 0-4 0v9.8a4 4 0 1 0 4 0Z"/><path ${f} d="M12 8v8"/>`);
    case "wallet":
      return $(`<path ${f} d="M4 7.5A2.5 2.5 0 0 1 6.5 5H18v4H6.5A2.5 2.5 0 0 1 4 6.5v10A2.5 2.5 0 0 0 6.5 19H20V9H6.5"/><path ${f} d="M16 13h2"/>`);
    case "wave":
      return $(`<path ${f} d="M3 13c2.2-6 4.4-6 6.6 0s4.4 6 6.6 0S20.6 7 23 13"/>`);
  }
}, U = (t, r) => {
  t.hidden !== r && (t.hidden = r);
}, oe = (t, r) => {
  t.textContent !== r && (t.textContent = r);
};
class Wr {
  root;
  renderedVariant;
  styleEl;
  titleEl;
  dashboardEl;
  warningEl;
  entityMapEl;
  flowScaleObserver;
  flowScaleCleanup;
  flowLineObserver;
  constructor(r) {
    this.root = r;
  }
  render(r, e) {
    this.ensureStructure(r), this.syncTitle(e.title), this.syncFields(e.values), this.syncFlags(e.flags), this.syncWarning(e.warning), this.syncEntityRows(e.entityRows), requestAnimationFrame(() => this.positionFlowLines());
  }
  ensureStructure(r) {
    if (this.renderedVariant === r && this.styleEl && this.dashboardEl && this.titleEl && this.warningEl && this.entityMapEl)
      return;
    this.flowScaleObserver?.disconnect(), this.flowScaleObserver = void 0, this.flowScaleCleanup?.(), this.flowScaleCleanup = void 0, this.flowLineObserver?.disconnect(), this.flowLineObserver = void 0, this.root.replaceChildren(), this.styleEl = document.createElement("style"), this.styleEl.textContent = rt();
    const e = document.createElement("ha-card"), o = document.createElement("div");
    o.className = "card-shell", this.titleEl = document.createElement("div"), this.titleEl.className = "card-title", this.dashboardEl = document.createElement("div"), this.dashboardEl.className = `energy-dashboard energy-dashboard--${r}`, this.dashboardEl.innerHTML = r === "summary" ? et() : Yr(), this.warningEl = document.createElement("div"), this.warningEl.className = "helper helper--warn", this.warningEl.hidden = !0, this.entityMapEl = document.createElement("div"), this.entityMapEl.className = "entity-map", this.entityMapEl.hidden = !0, o.append(this.titleEl, this.dashboardEl, this.warningEl, this.entityMapEl), e.append(o), this.root.append(this.styleEl, e), this.renderedVariant = r, this.setupFlowScaling(r), this.setupFlowLinePositioning();
  }
  setupFlowScaling(r) {
    if (!this.dashboardEl) return;
    if (r === "summary") {
      const l = this.dashboardEl.querySelector(".summary-scale-frame"), d = l?.querySelector(".summary-shell");
      if (!l || !d) return;
      const m = window.matchMedia("(min-width: 1025px)"), y = () => {
        const g = l.clientWidth;
        if (g <= 0) return;
        if (!m.matches) {
          l.style.removeProperty("--summary-scaled-height"), d.style.removeProperty("--summary-scale"), requestAnimationFrame(() => this.positionFlowLines());
          return;
        }
        const h = Math.max(d.scrollWidth, d.offsetWidth), Q = Math.min(1, g / h);
        d.style.setProperty("--summary-scale", String(Q)), Q < 1 ? l.style.setProperty("--summary-scaled-height", `${d.scrollHeight * Q}px`) : l.style.removeProperty("--summary-scaled-height"), requestAnimationFrame(() => this.positionFlowLines());
      };
      this.flowScaleObserver = new ResizeObserver(() => y()), this.flowScaleObserver.observe(l), this.flowScaleObserver.observe(d), m.addEventListener("change", y), window.addEventListener("resize", y), this.flowScaleCleanup = () => {
        m.removeEventListener("change", y), window.removeEventListener("resize", y);
      }, requestAnimationFrame(y);
      return;
    }
    if (r !== "detailed") return;
    const e = this.dashboardEl.querySelector(".flow-scale-frame"), o = e?.querySelector(".flow-board--detailed");
    if (!e || !o) return;
    const n = () => {
      const l = e.clientWidth;
      if (l <= 0) return;
      const d = Math.min(1, l / 1024);
      e.style.setProperty("--flow-scale", String(d)), d < 1 ? e.style.setProperty("--flow-scaled-height", `${o.scrollHeight * d}px`) : e.style.removeProperty("--flow-scaled-height");
    };
    this.flowScaleObserver = new ResizeObserver(() => n()), this.flowScaleObserver.observe(e), this.flowScaleObserver.observe(o), requestAnimationFrame(n);
  }
  setupFlowLinePositioning() {
    if (!this.dashboardEl) return;
    const r = Array.from(this.dashboardEl.querySelectorAll(".flow-board"));
    if (!r.length) return;
    const e = () => this.positionFlowLines();
    this.flowLineObserver = new ResizeObserver(() => e()), this.flowLineObserver.observe(this.dashboardEl);
    for (const o of r) {
      this.flowLineObserver.observe(o);
      for (const n of o.querySelectorAll("[data-flow-node]"))
        this.flowLineObserver.observe(n);
    }
    requestAnimationFrame(e);
  }
  positionFlowLines() {
    if (this.dashboardEl)
      for (const r of this.dashboardEl.querySelectorAll("[data-flow-line][data-flow-from][data-flow-to]")) {
        const e = r.closest(".flow-board");
        if (!e) continue;
        const o = e.querySelector(`[data-flow-node="${r.dataset.flowFrom}"]`), n = e.querySelector(`[data-flow-node="${r.dataset.flowTo}"]`);
        if (!o || !n) continue;
        const l = e.getBoundingClientRect(), d = o.getBoundingClientRect(), m = n.getBoundingClientRect(), y = e.offsetWidth > 0 ? l.width / e.offsetWidth : 1, g = y > 0 ? y : 1, h = (d.left + d.width / 2 - l.left) / g, Q = (d.top + d.height / 2 - l.top) / g, M = (m.left + m.width / 2 - l.left) / g, P = (m.top + m.height / 2 - l.top) / g, V = M - h, E = P - Q, I = Math.hypot(V, E), J = Math.atan2(E, V) * (180 / Math.PI);
        r.style.left = `${h}px`, r.style.top = `${Q}px`, r.style.width = `${I}px`, r.style.transform = `translateY(-50%) rotate(${J}deg)`;
      }
  }
  syncTitle(r) {
    this.titleEl && (oe(this.titleEl, r), U(this.titleEl, r.trim().length === 0));
  }
  syncFields(r) {
    if (this.dashboardEl)
      for (const e of this.dashboardEl.querySelectorAll("[data-field]"))
        oe(e, r[e.dataset.field ?? ""] ?? "");
  }
  syncFlags(r) {
    if (this.dashboardEl) {
      for (const [e, o] of Object.entries(r))
        this.dashboardEl.classList.toggle(`is-${e.replace(/_/g, "-")}`, o);
      this.syncFlowLines(r);
    }
  }
  syncFlowLines(r) {
    if (this.dashboardEl)
      for (const e of this.dashboardEl.querySelectorAll("[data-flow-line]")) {
        const n = (e.dataset.flowLine ?? "").replace(/-/g, "_"), l = r[`flow_${n}_active`] ?? !1, d = r[`flow_${n}_reverse`] ?? !1, m = r[`flow_${n}_forward`] ?? !0;
        e.classList.toggle("active", l), e.classList.toggle("reverse", l && d), e.classList.toggle("forward", l && !d && m);
      }
  }
  syncWarning(r) {
    if (!this.warningEl) return;
    const e = r ?? "";
    oe(this.warningEl, e), U(this.warningEl, e.trim().length === 0);
  }
  syncEntityRows(r) {
    if (!this.entityMapEl) return;
    if (!r?.length) {
      U(this.entityMapEl, !0), this.entityMapEl.childElementCount > 0 && this.entityMapEl.replaceChildren();
      return;
    }
    const e = document.createDocumentFragment();
    for (const [o, n] of r) {
      const l = document.createElement("div");
      l.className = "entity-row";
      const d = document.createElement("span"), m = document.createElement("span");
      d.textContent = o, m.textContent = n, l.append(d, m), e.append(l);
    }
    this.entityMapEl.replaceChildren(e), U(this.entityMapEl, !1), requestAnimationFrame(() => this.positionFlowLines());
  }
}
const a = {
  battery: "&#1040;&#1082;&#1091;&#1084;&#1091;&#1083;&#1103;&#1090;&#1086;&#1088;",
  costDay: "&#1042;&#1072;&#1088;&#1090;&#1110;&#1089;&#1090;&#1100; &#1079;&#1072; &#1076;&#1077;&#1085;&#1100;",
  current: "&#1057;&#1090;&#1088;&#1091;&#1084;:",
  acTemperature: "AC &#1090;&#1077;&#1084;&#1087;&#1077;&#1088;&#1072;&#1090;&#1091;&#1088;&#1072;",
  dcTemperature: "DC &#1090;&#1077;&#1084;&#1087;&#1077;&#1088;&#1072;&#1090;&#1091;&#1088;&#1072;",
  exportDay: "&#1055;&#1088;&#1086;&#1076;&#1072;&#1078; &#1079;&#1072; &#1076;&#1077;&#1085;&#1100;",
  frequency: "&#1063;&#1072;&#1089;&#1090;&#1086;&#1090;&#1072; &#1084;&#1077;&#1088;&#1077;&#1078;&#1110;",
  generatorDay: "&#1043;&#1077;&#1085;&#1077;&#1088;&#1072;&#1090;&#1086;&#1088; &#1079;&#1072; &#1076;&#1077;&#1085;&#1100;",
  generator: "&#1043;&#1077;&#1085;&#1077;&#1088;&#1072;&#1090;&#1086;&#1088;",
  grid: "&#1052;&#1077;&#1088;&#1077;&#1078;&#1072;",
  gridLoad: "&#1053;&#1072;&#1074;&#1072;&#1085;&#1090;&#1072;&#1078;&#1077;&#1085;&#1085;&#1103; &#1085;&#1072; &#1084;&#1077;&#1088;&#1077;&#1078;&#1091;",
  gridLoadSub: "&#1087;&#1086;&#1090;&#1091;&#1078;&#1085;&#1110; &#1087;&#1088;&#1080;&#1083;&#1072;&#1076;&#1080;",
  importDay: "&#1050;&#1091;&#1087;&#1110;&#1074;&#1083;&#1103; &#1079;&#1072; &#1076;&#1077;&#1085;&#1100;",
  inverter: "&#1030;&#1085;&#1074;&#1077;&#1088;&#1090;&#1086;&#1088;",
  lastUpdate: "&#1054;&#1089;&#1090;&#1072;&#1085;&#1085;&#1108; &#1086;&#1085;&#1086;&#1074;&#1083;&#1077;&#1085;&#1085;&#1103;:",
  phasePower: "&#1055;&#1086;&#1090;&#1091;&#1078;&#1085;&#1110;&#1089;&#1090;&#1100; &#1087;&#1086; &#1092;&#1072;&#1079;&#1072;&#1093;",
  phases: "&#1060;&#1072;&#1079;&#1080;:",
  power: "&#1055;&#1086;&#1090;&#1091;&#1078;&#1085;&#1110;&#1089;&#1090;&#1100;",
  productionDay: "&#1043;&#1077;&#1085;&#1077;&#1088;&#1072;&#1094;&#1110;&#1103; &#1079;&#1072; &#1076;&#1077;&#1085;&#1100;",
  pvGeneration: "PV &#1075;&#1077;&#1085;&#1077;&#1088;&#1072;&#1094;&#1110;&#1103;",
  pvField1: "PV &#1087;&#1086;&#1083;&#1077; 1",
  pvField2: "PV &#1087;&#1086;&#1083;&#1077; 2",
  selfConsumption: "&#1042;&#1083;&#1072;&#1089;&#1085;&#1077; &#1089;&#1087;&#1086;&#1078;&#1080;&#1074;&#1072;&#1085;&#1085;&#1103;",
  status: "&#1057;&#1090;&#1072;&#1090;&#1091;&#1089;",
  system: "&#1057;&#1080;&#1089;&#1090;&#1077;&#1084;&#1072;",
  temperature: "&#1058;&#1077;&#1084;&#1087;&#1077;&#1088;&#1072;&#1090;&#1091;&#1088;&#1072;",
  upsLoad: "UPS &#1085;&#1072;&#1074;&#1072;&#1085;&#1090;&#1072;&#1078;&#1077;&#1085;&#1085;&#1103;",
  upsLoadSub: "&#1086;&#1089;&#1085;&#1086;&#1074;&#1085;&#1077;",
  voltage: "&#1053;&#1072;&#1087;&#1088;&#1091;&#1075;&#1072;:"
}, v = (t) => `<span class="icon icon--${t}">${we(t)}</span>`, be = () => `
  <span class="battery-icon-stack" aria-hidden="true">
    ${v("batteryEmpty")}
    ${v("batteryLow")}
    ${v("batteryHalf")}
    ${v("batteryFull")}
    ${v("batteryBolt")}
  </span>
`, _ = (t, r, e, o, n = "", l = "arrowUpRight") => `
  <article class="chip chip--${t}">
    ${v(r)}
    <div class="chip__content">
      <div class="chip__label">${e}</div>
      <div class="chip__value"><span data-field="${o}"></span>${n ? `<small data-field="${n}"></small>` : ""}</div>
    </div>
    <span class="chip__trend">${we(l)}</span>
  </article>
`, w = (t, r) => `
  <div class="metric-line"><span>${t}</span><strong data-field="${r}"></strong></div>
`, x = (t, r, e, o = "") => `
  <div class="power-readout ${o ? `power-readout--${o}` : ""}">
    <span>${t}</span>
    <strong><span data-field="${r}"></span><small data-field="${e}"></small></strong>
  </div>
`, me = (t, r, e, o, n) => `
  <div class="power-readout summary-inverter-readout power-readout--${n}">
    <div class="summary-readout-main">
      ${v(t)}
      <strong><span data-field="${r}"></span><small data-field="${e}"></small></strong>
    </div>
    <div class="summary-readout-meta summary-readout-meta--${n}">
      ${v("thermometer")}
      <strong data-field="${o}"></strong>
    </div>
  </div>
`, ue = (t, r, e, o) => `
  <div class="power-readout summary-metric-readout power-readout--${o}">
    ${v(r)}
    <span>${t}</span>
    <strong data-field="${e}"></strong>
  </div>
`, C = (t, r, e = "") => `
  <header class="node-title">
    ${v(t)}
    <div>
      <h3>${r}</h3>
      ${e ? `<p>${e}</p>` : ""}
    </div>
  </header>
`, L = (t, r, e) => `<span class="flow-line line-${t}" data-flow-line="${t}" data-flow-from="${r}" data-flow-to="${e}" aria-hidden="true"></span>`, Ur = () => `
  <div class="detail-flow-lines" aria-hidden="true">
    ${L("pv1-inverter", "pv1", "inverter")}
    ${L("pv2-inverter", "pv2", "inverter")}
    ${L("battery-inverter", "battery", "inverter")}
    ${L("inverter-grid", "inverter", "grid")}
    ${L("generator-inverter", "generator", "inverter")}
    ${L("inverter-ups", "inverter", "ups")}
    ${L("grid-load", "grid", "grid-load")}
  </div>
`, Kr = () => `
  <div class="summary-flow-lines" aria-hidden="true">
    ${L("pv-inverter", "pv-total", "inverter")}
    ${L("inverter-grid", "inverter", "grid")}
    ${L("inverter-ups", "inverter", "ups")}
    ${L("battery-inverter", "battery", "inverter")}
    ${L("grid-load", "grid", "grid-load")}
  </div>
`, Jr = () => `
  <section class="summary-chips" aria-label="Daily summary">
    ${_("green", "sun", a.productionDay, "daily.production.value", "daily.production.unit")}
    ${_("amber", "cart", a.importDay, "daily.import.value", "daily.import.unit")}
    ${_("green", "arrowUpRight", a.exportDay, "daily.export.value", "daily.export.unit")}
    ${_("amber", "generator", a.generatorDay, "daily.generator.value", "daily.generator.unit")}
    ${_("blue", "home", a.selfConsumption, "system.self_consumption", "")}
    ${_("purple", "wallet", a.costDay, "daily.cost.value", "daily.cost.unit", "arrowDown")}
  </section>
`, Yr = () => `
  <section class="detailed-shell">
    <aside class="side-rail">
      <div class="sidebar-chips">
        ${_("green", "shield", a.system, "system.online", "")}
        ${_("green", "sun", a.productionDay, "daily.production.value", "daily.production.unit")}
        ${_("green", "arrowUpRight", a.exportDay, "daily.export.value", "daily.export.unit")}
        ${_("amber", "cart", a.importDay, "daily.import.value", "daily.import.unit")}
        ${_("amber", "generator", a.generatorDay, "daily.generator.value", "daily.generator.unit")}
        ${_("purple", "wallet", a.costDay, "daily.cost.value", "daily.cost.unit", "arrowDown")}
        ${_("blue", "home", a.selfConsumption, "system.self_consumption", "")}
        ${_("muted", "clock", a.lastUpdate, "system.updated_at", "")}
      </div>
    </aside>
    <div class="flow-scale-frame">
      <section class="flow-board flow-board--detailed" aria-label="Energy flow">
        ${Ur()}
        <div class="flow-row flow-row--pv">
          <article class="node node--pv node--pv1" data-flow-node="pv1">
            ${C("solarPanel", a.pvField1)}
            ${w(a.voltage, "pv1.voltage")}
            ${w(a.current, "pv1.current")}
            ${x(a.power, "pv1.power.value", "pv1.power.unit", "green")}
          </article>
          <article class="node node--pv node--pv2" data-flow-node="pv2">
            ${C("solarPanel", a.pvField2)}
            ${w(a.voltage, "pv2.voltage")}
            ${w(a.current, "pv2.current")}
            ${x(a.power, "pv2.power.value", "pv2.power.unit", "green")}
          </article>
        </div>
        <div class="flow-row flow-row--middle">
          <div class="node-slot node-slot--grid">
            <article class="node node--grid" data-flow-node="grid">
              ${C("grid", a.grid)}
              ${w(a.phases, "grid.phases")}
              ${w(a.current, "grid.current")}
              ${w(a.frequency, "system.frequency")}
              <div class="phase-row"><span>${a.phasePower}</span><strong data-field="grid.phase_power"></strong></div>
              ${x(a.power, "grid.power.value", "grid.power.unit", "blue")}
              <div class="node-status node-status--blue">${v("arrowDown")}<span data-field="grid.status"></span></div>
            </article>
          </div>
          <article class="node node--inverter" data-flow-node="inverter">
            <div class="inverter-layout">
              <div class="inverter-left">
                <div class="inverter-state">
                  ${v("inverter")}
                  <div>
                    <span>${a.status}</span>
                    <strong data-field="inverter.status"></strong>
                  </div>
                </div>
                <div class="inverter-kpis">
                  ${x("AC", "inverter.ac_power.value", "inverter.ac_power.unit", "cyan")}
                  ${x("DC", "inverter.dc_power.value", "inverter.dc_power.unit", "green")}
                </div>
              </div>
              <div class="inverter-right">
                <header class="inverter-heading">
                  <h2>${a.inverter}</h2>
                  <span>AC / DC</span>
                </header>
                <div class="inverter-lines">
                  ${w(`${a.phases}`, "inverter.phases")}
                  ${w(a.current, "inverter.current")}
                  ${w("Hz:", "inverter.frequency")}
                  ${w(a.acTemperature, "inverter.ac_temperature")}
                  ${w(a.dcTemperature, "inverter.dc_temperature")}
                </div>
              </div>
            </div>
          </article>
          <div class="node-slot node-slot--ups">
            <article class="node node--ups" data-flow-node="ups">
              ${C("homeDay", a.upsLoad, a.upsLoadSub)}
              ${w(a.phases, "ups.phases")}
              ${w(a.current, "ups.current")}
              <div class="phase-row"><span>${a.phasePower}</span><strong data-field="ups.phase_power"></strong></div>
              ${x(a.power, "ups.power.value", "ups.power.unit", "cyan")}
            </article>
          </div>
        </div>
        <div class="flow-row flow-row--bottom">
          <article class="node node--grid-load" data-flow-node="grid-load">
            ${C("home", a.gridLoad, a.gridLoadSub)}
            ${w(a.phases, "grid_load.phases")}
            ${w(a.current, "grid_load.current")}
            <div class="phase-row"><span>${a.phasePower}</span><strong data-field="grid_load.phase_power"></strong></div>
            ${x(a.power, "grid_load.power.value", "grid_load.power.unit", "blue")}
          </article>
          <article class="node node--generator" data-flow-node="generator">
            ${C("generator", a.generator)}
            ${w(a.phases, "generator.phases")}
            ${w(a.current, "generator.current")}
            <div class="phase-row"><span>${a.phasePower}</span><strong data-field="generator.phase_power"></strong></div>
            ${x(a.power, "generator.power.value", "generator.power.unit", "amber")}
            <div class="node-status node-status--amber"><span>${a.status}:</span><strong data-field="generator.status"></strong></div>
          </article>
          <article class="node node--battery" data-flow-node="battery">
            <h3 class="battery-heading">${a.battery}</h3>
            <div class="battery-grid">
              <div class="soc-ring">${be()}<strong><span data-field="battery.soc.value"></span><small data-field="battery.soc.unit"></small></strong><span>SOC</span></div>
              <div class="battery-data">
                ${w(a.voltage, "battery.voltage")}
                ${w(a.current, "battery.current")}
                ${x(a.power, "battery.power.value", "battery.power.unit", "green")}
                <strong class="battery-mode" data-field="battery.mode"></strong>
              </div>
              <div class="battery-temp">${v("thermometer")}<span>${a.temperature}</span><strong data-field="battery.temperature"></strong></div>
            </div>
          </article>
        </div>
      </section>
    </div>
  </section>
`, et = () => `
  <div class="summary-scale-frame">
    <section class="summary-shell">
      ${Jr()}
      <section class="flow-board flow-board--summary" aria-label="Energy summary flow">
        ${Kr()}
        <article class="node node--pv-total summary-node" data-flow-node="pv-total">
          ${C("solarPanel", a.pvGeneration)}
          ${x("DC", "pv.total.power.value", "pv.total.power.unit", "green")}
        </article>
        <article class="node node--grid summary-node" data-flow-node="grid">
          ${C("grid", a.grid)}
          ${x(a.power, "grid.power.value", "grid.power.unit", "blue")}
          <div class="node-status node-status--blue">${v("arrowDown")}<span data-field="grid.status"></span></div>
        </article>
        <article class="node node--grid-load summary-node" data-flow-node="grid-load">
          ${C("home", a.gridLoad)}
          ${x(a.power, "grid_load.power.value", "grid_load.power.unit", "blue")}
        </article>
        <article class="node node--inverter summary-inverter" data-flow-node="inverter">
          <header class="summary-inverter__head">
            ${v("inverter")}
            <div>
              <h2>${a.inverter}</h2>
              <span data-field="inverter.status"></span>
            </div>
          </header>
          <div class="summary-inverter__power">
            ${me("wave", "inverter.ac_power.value", "inverter.ac_power.unit", "inverter.ac_temperature_compact", "cyan")}
            ${me("solarPanel", "inverter.dc_power.value", "inverter.dc_power.unit", "inverter.dc_temperature_compact", "green")}
          </div>
        </article>
        <article class="node node--ups summary-node" data-flow-node="ups">
          ${C("homeDay", a.upsLoad)}
          ${x(a.power, "ups.power.value", "ups.power.unit", "cyan")}
        </article>
        <article class="node node--battery summary-battery-node" data-flow-node="battery">
          <div class="summary-battery">
            <div class="soc-ring">${be()}<strong><span data-field="battery.soc.value"></span><small data-field="battery.soc.unit"></small></strong><span>SOC</span></div>
            <div class="summary-battery__data">
              ${x(a.power, "battery.power.value", "battery.power.unit", "green")}
              <div class="summary-battery__stats">
                ${ue("Напруга", "battery", "battery.voltage", "green")}
                ${ue("Температура", "thermometer", "battery.temperature", "green")}
              </div>
            </div>
          </div>
        </article>
      </section>
    </section>
  </div>
`, rt = () => `
  :host {
    display: block;
    width: 100%;
    min-width: 0;
    min-inline-size: 0;
    max-width: 100%;
    max-inline-size: 100%;
    overflow: hidden;
    container-type: inline-size;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  [hidden] {
    display: none !important;
  }

  ha-card {
    display: block;
    width: 100%;
    min-width: 0;
    min-inline-size: 0;
    max-width: 100%;
    max-inline-size: 100%;
    overflow: hidden;
    border: 1px solid rgba(160, 218, 255, 0.16);
    border-radius: 10px;
    background:
      radial-gradient(circle at 50% 40%, rgba(0, 216, 255, 0.08), transparent 42%),
      linear-gradient(180deg, #061018 0%, #02070b 100%);
    color: #eff8ff;
    box-shadow: 0 20px 46px rgba(0, 0, 0, 0.34);
  }

  .card-shell {
    min-width: 0;
    min-inline-size: 0;
    display: grid;
    gap: 14px;
    padding: 16px;
    font-family: Inter, "Segoe UI", system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
  }

  .card-title {
    color: rgba(239, 248, 255, 0.68);
    font-size: clamp(11px, 1cqw, 14px);
    font-weight: 600;
  }

  .energy-dashboard {
    --green: #38ef77;
    --cyan: #00d8ff;
    --blue: #4aa3ff;
    --amber: #ffbf2f;
    --purple: #9a72ff;
    --red: #ff5a65;
    --panel: rgba(8, 21, 30, 0.9);
    --panel2: rgba(12, 29, 39, 0.9);
    --line: rgba(255, 255, 255, 0.14);
    --muted: rgba(239, 248, 255, 0.7);
    display: grid;
    gap: 14px;
    min-width: 0;
    min-inline-size: 0;
  }

  .energy-dashboard--detailed {
    --detail-card-gap: 24px;
    --detail-row-gap: 30px;
    --detail-node-pad: 11px;
    --detail-icon-size: 36px;
    --detail-title-size: clamp(13px, 0.95cqw, 18px);
    --detail-copy-size: clamp(10px, 0.72cqw, 13px);
    --detail-value-size: clamp(18px, 1.34cqw, 25px);
  }

  .top-strip {
    display: grid;
    gap: 12px;
  }

  .detailed-shell {
    display: grid;
    grid-template-columns: minmax(210px, 242px) minmax(0, 1fr);
    gap: var(--detail-card-gap);
    align-items: stretch;
    min-width: 0;
    min-inline-size: 0;
  }

  .side-rail {
    display: grid;
    min-height: 0;
    align-content: stretch;
  }

  .sidebar-chips {
    min-height: 0;
    display: grid;
    grid-template-rows: repeat(8, minmax(0, 1fr));
    gap: 8px;
    align-self: stretch;
  }

  .chip-row,
  .badge-row {
    display: grid;
    gap: 12px;
  }

  .chip-row {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }

  .badge-row {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }

  .chip,
  .status-badge,
  .node,
  .system-panel {
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 8px;
    background:
      linear-gradient(140deg, #122834, #050e15);
    box-shadow: inset 0 0 38px rgba(255, 255, 255, 0.025);
  }

  .chip {
    min-width: 0;
    min-height: 82px;
    display: grid;
    grid-template-columns: 58px minmax(0, 1fr) 28px;
    gap: 12px;
    align-items: center;
    padding: 12px 16px;
  }

  .side-rail .chip {
    min-height: 0;
    grid-template-columns: 45px minmax(0, 1fr);
    gap: 8px;
    padding: 7px 10px;
    background: rgba(255, 255, 255, 0.045);
    box-shadow: inset 0 0 26px rgba(255, 255, 255, 0.018);
  }

  .side-rail .chip > .icon {
    width: 40px;
    height: 40px;
    font-size: 24px;
    padding: 0;
    border-radius: 0;
    background: transparent;
  }

  .side-rail .chip__content {
    min-width: 0;
    display: grid;
    gap: 8px;
    align-items: baseline;
  }

  .side-rail .chip__label {
    overflow: hidden;
    color: rgba(239, 248, 255, 0.78);
    font-size: clamp(10px, 1cqw, 20px);
    line-height: 1.15;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .side-rail .chip__value {
    gap: 4px;
    margin: 0;
    font-size: clamp(13px, 1.4cqw, 20px);
    font-weight: 750;
  }

  .side-rail .chip__value small {
    font-size: 0.68em;
  }

  .side-rail .chip__trend {
    display: none;
  }

  .chip--green { border-color: rgba(56, 239, 119, 0.24); box-shadow: inset 0 0 46px rgba(56, 239, 119, 0.07); }
  .chip--blue { border-color: rgba(74, 163, 255, 0.26); box-shadow: inset 0 0 46px rgba(74, 163, 255, 0.07); }
  .chip--amber { border-color: rgba(255, 191, 47, 0.26); box-shadow: inset 0 0 46px rgba(255, 191, 47, 0.08); }
  .chip--purple { border-color: rgba(154, 114, 255, 0.28); box-shadow: inset 0 0 46px rgba(154, 114, 255, 0.09); }
  .chip--muted { border-color: rgba(239, 248, 255, 0.16); box-shadow: inset 0 0 46px rgba(255, 255, 255, 0.035); }

  .side-rail .chip--green { border-color: rgba(56, 239, 119, 0.26); background: rgba(23, 132, 59, 0.11); box-shadow: inset 0 0 26px rgba(255, 255, 255, 0.018); }
  .side-rail .chip--blue { border-color: rgba(74, 163, 255, 0.26); background: rgba(31, 92, 153, 0.12); box-shadow: inset 0 0 26px rgba(255, 255, 255, 0.018); }
  .side-rail .chip--amber { border-color: rgba(255, 191, 47, 0.26); background: rgba(255, 191, 47, 0.08); box-shadow: inset 0 0 26px rgba(255, 255, 255, 0.018); }
  .side-rail .chip--purple { border-color: rgba(154, 114, 255, 0.28); background: rgba(154, 114, 255, 0.08); box-shadow: inset 0 0 26px rgba(255, 255, 255, 0.018); }
  .side-rail .chip--muted { border-color: rgba(239, 248, 255, 0.14); background: rgba(255, 255, 255, 0.045); box-shadow: inset 0 0 26px rgba(255, 255, 255, 0.018); }

  .chip > .icon {
    width: 54px;
    height: 54px;
    display: grid;
    place-items: center;
    padding: 10px;
    border-radius: 50%;
    color: var(--green);
    background: rgba(56, 239, 119, 0.12);
  }

  .chip--amber > .icon { color: var(--amber); background: rgba(255, 191, 47, 0.12); }
  .chip--blue > .icon { color: var(--blue); background: rgba(74, 163, 255, 0.12); }
  .chip--purple > .icon { color: var(--purple); background: rgba(154, 114, 255, 0.12); }
  .chip--muted > .icon { color: rgba(239, 248, 255, 0.58); background: rgba(255, 255, 255, 0.08); }

  .chip__label {
    min-width: 0;
    color: var(--muted);
    font-size: clamp(12px, 1cqw, 16px);
    line-height: 1.15;
  }

  .chip__value {
    display: flex;
    align-items: baseline;
    gap: 7px;
    margin-top: 7px;
    color: var(--green);
    font-size: clamp(22px, 2cqw, 34px);
    font-weight: 600;
    line-height: 1;
    white-space: nowrap;
  }

  .chip--amber .chip__value { color: var(--amber); }
  .chip--blue .chip__value { color: var(--blue); }
  .chip--purple .chip__value { color: var(--purple); }
  .chip--muted .chip__value { color: #f4f8ff; }
  .chip__value small { font-size: 0.58em; font-weight: 500; }
  .chip__trend { color: var(--green); }
  .chip--blue .chip__trend { color: var(--blue); }
  .chip--amber .chip__trend { color: var(--amber); }
  .chip--purple .chip__trend { color: var(--purple); }

  .status-badge {
    min-height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 8px 12px;
    color: var(--muted);
    font-size: clamp(12px, 1cqw, 16px);
    font-weight: 600;
    line-height: 1.18;
    text-align: left;
  }

  .side-rail .status-badge {
    min-height: 40px;
    display: grid;
    grid-template-columns: 22px minmax(0, 1fr);
    gap: 8px;
    justify-content: stretch;
    padding: 7px 10px;
    background: rgba(255, 255, 255, 0.045);
    font-size: clamp(10px, 0.82cqw, 12px);
    box-shadow: inset 0 0 26px rgba(255, 255, 255, 0.018);
  }

  .side-rail .status-badge .icon {
    width: 21px;
    height: 21px;
    font-size: 21px;
  }

  .side-rail .status-badge span {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .status-badge--blue { color: var(--blue); border-color: rgba(74, 163, 255, 0.32); background: rgba(31, 92, 153, 0.18); }
  .status-badge--green { color: var(--green); border-color: rgba(56, 239, 119, 0.3); background: rgba(23, 132, 59, 0.2); }
  .status-badge--muted { color: rgba(239, 248, 255, 0.78); background: rgba(255, 255, 255, 0.06); }

  .sidebar-chips > .chip:first-child {
    border-color: rgba(56, 239, 119, 0.34);
    background: rgba(23, 132, 59, 0.16);
  }

  .icon,
  .chip__trend {
    width: 28px;
    height: 28px;
    display: inline-grid;
    flex: 0 0 auto;
    place-items: center;
    color: currentColor;
    font-size: 28px;
  }

  .icon svg,
  .chip__trend svg,
  .sync-icon svg {
    width: 100%;
    height: 100%;
    display: block;
    filter: drop-shadow(0 0 7px currentColor);
  }

  .flow-board {
    position: relative;
    display: grid;
    gap: 16px;
    isolation: isolate;
    overflow: hidden;
  }

  .flow-scale-frame {
    display: block;
    min-width: 0;
    min-inline-size: 0;
    max-width: 100%;
    max-inline-size: 100%;
    contain: inline-size layout paint;
  }

  .flow-board--detailed {
    grid-template-columns: 1fr;
    min-height: 0;
    overflow: visible;
    gap: var(--detail-row-gap);
  }

  .flow-row {
    min-width: 0;
    display: grid;
    gap: var(--detail-card-gap);
    align-items: stretch;
  }

  .node-slot {
    min-width: 0;
    display: grid;
    align-content: center;
  }

  .node-slot > .node {
    min-height: 0;
  }

  .flow-row--pv {
    grid-template-columns: repeat(2, minmax(198px, 258px));
    gap: clamp(54px, 8cqw, 126px);
    justify-content: center;
  }

  .flow-row--middle {
    grid-template-columns: minmax(198px, 0.78fr) minmax(430px, 1.46fr) minmax(218px, 0.86fr);
    gap: clamp(28px, 4cqw, 58px);
  }

  .flow-row--bottom {
    grid-template-columns: minmax(218px, 0.9fr) minmax(218px, 0.9fr) minmax(350px, 1.28fr);
    gap: clamp(24px, 3.4cqw, 48px);
  }

  .flow-board--summary {
    width: 100%;
    min-width: 0;
    min-inline-size: 0;
    max-width: 100%;
    max-inline-size: 100%;
    grid-template-columns: minmax(188px, 0.9fr) minmax(300px, 1.22fr) minmax(188px, 0.9fr);
    grid-template-rows: minmax(70px, 0.74fr) minmax(132px, 1.18fr) minmax(76px, 0.8fr);
    grid-template-areas:
      ". pv ."
      "grid inverter load"
      "grid-load battery .";
    gap: clamp(12px, 1.8cqw, 24px) clamp(18px, 3.2cqw, 44px);
    align-items: center;
    height: 100%;
    min-height: 0;
    padding: clamp(4px, 0.8cqw, 10px) clamp(2px, 0.6cqw, 8px);
    overflow: visible;
  }

  .energy-dashboard--detailed .flow-lines {
    display: none;
  }

  .detail-flow-lines {
    position: absolute;
    inset: 0;
    z-index: 0;
    pointer-events: none;
    overflow: visible;
  }

  .summary-flow-lines {
    position: absolute;
    inset: 0;
    z-index: 0;
    pointer-events: none;
    overflow: visible;
  }

  .flow-board--detailed .flow-line {
    position: absolute;
    z-index: 0;
    height: 4px;
    transform-origin: left center;
    border-radius: 999px;
    background: rgba(180, 205, 218, 0.18);
    overflow: hidden;
    opacity: 0;
    --flow-rgb: 126, 197, 255;
    --flow-speed: 1.25s;
    --flow-texture-speed: 0.55s;
  }

  .flow-board--summary .flow-line {
    position: absolute;
    z-index: 0;
    height: 4px;
    transform-origin: left center;
    border-radius: 999px;
    background: rgba(180, 205, 218, 0.16);
    overflow: hidden;
    opacity: 0;
    --flow-rgb: 126, 197, 255;
    --flow-speed: 1.2s;
    --flow-texture-speed: 0.62s;
  }

  .flow-board--detailed .flow-line::before {
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    width: 34%;
    border-radius: inherit;
    background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(var(--flow-rgb), 0.15) 18%,
      rgba(var(--flow-rgb), 1) 50%,
      rgba(var(--flow-rgb), 0.15) 82%,
      transparent 100%
    );
    opacity: 0;
    transform: translateX(-120%);
    box-shadow: 0 0 12px rgba(var(--flow-rgb), 0.65);
    will-change: transform, opacity;
  }

  .flow-board--detailed .flow-line::after {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: inherit;
    background: repeating-linear-gradient(
      90deg,
      transparent 0,
      transparent 9px,
      rgba(var(--flow-rgb), 0.4) 9px,
      rgba(var(--flow-rgb), 0.4) 16px,
      transparent 16px,
      transparent 22px
    );
    background-size: 44px 100%;
    opacity: 0;
    will-change: background-position, opacity;
  }

  .flow-board--summary .flow-line::before {
    content: "";
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    width: 34%;
    border-radius: inherit;
    background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(var(--flow-rgb), 0.15) 18%,
      rgba(var(--flow-rgb), 1) 50%,
      rgba(var(--flow-rgb), 0.15) 82%,
      transparent 100%
    );
    opacity: 0;
    transform: translateX(-120%);
    box-shadow: 0 0 12px rgba(var(--flow-rgb), 0.65);
    will-change: transform, opacity;
  }

  .flow-board--summary .flow-line::after {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: inherit;
    background: repeating-linear-gradient(
      90deg,
      transparent 0,
      transparent 9px,
      rgba(var(--flow-rgb), 0.4) 9px,
      rgba(var(--flow-rgb), 0.4) 16px,
      transparent 16px,
      transparent 22px
    );
    background-size: 44px 100%;
    opacity: 0;
    will-change: background-position, opacity;
  }

  .flow-board--detailed .flow-line.active {
    opacity: 1;
    background:
      linear-gradient(
        90deg,
        transparent 0%,
        rgba(var(--flow-rgb), 0.18) 8%,
        rgba(var(--flow-rgb), 0.78) 18%,
        rgba(var(--flow-rgb), 0.18) 30%,
        transparent 42%
      ),
      linear-gradient(
        90deg,
        rgba(var(--flow-rgb), 0.12),
        rgba(var(--flow-rgb), 0.82),
        rgba(var(--flow-rgb), 0.12)
      );
    background-size: 72px 100%, 100% 100%;
    box-shadow:
      0 0 8px rgba(var(--flow-rgb), 0.55),
      0 0 18px rgba(var(--flow-rgb), 0.32),
      0 0 34px rgba(var(--flow-rgb), 0.16);
    animation: jks-power-flow-base calc(var(--flow-speed) * 1.35) linear infinite;
  }

  .flow-board--summary .flow-line.active {
    opacity: 1;
    background:
      linear-gradient(
        90deg,
        transparent 0%,
        rgba(var(--flow-rgb), 0.18) 8%,
        rgba(var(--flow-rgb), 0.78) 18%,
        rgba(var(--flow-rgb), 0.18) 30%,
        transparent 42%
      ),
      linear-gradient(
        90deg,
        rgba(var(--flow-rgb), 0.12),
        rgba(var(--flow-rgb), 0.82),
        rgba(var(--flow-rgb), 0.12)
      );
    background-size: 72px 100%, 100% 100%;
    box-shadow:
      0 0 8px rgba(var(--flow-rgb), 0.55),
      0 0 18px rgba(var(--flow-rgb), 0.32),
      0 0 34px rgba(var(--flow-rgb), 0.16);
    animation: jks-power-flow-base calc(var(--flow-speed) * 1.35) linear infinite;
  }

  .flow-board--detailed .flow-line.active::before {
    opacity: 1;
    animation: jks-power-flow-pulse var(--flow-speed) linear infinite;
  }

  .flow-board--summary .flow-line.active::before {
    opacity: 1;
    animation: jks-power-flow-pulse var(--flow-speed) linear infinite;
  }

  .flow-board--detailed .flow-line.active::after {
    opacity: 0.72;
    animation: jks-power-flow-texture var(--flow-texture-speed) linear infinite;
  }

  .flow-board--summary .flow-line.active::after {
    opacity: 0.72;
    animation: jks-power-flow-texture var(--flow-texture-speed) linear infinite;
  }

  .flow-board--detailed .flow-line.reverse.active::before {
    animation-name: jks-power-flow-pulse-reverse;
  }

  .flow-board--summary .flow-line.reverse.active::before {
    animation-name: jks-power-flow-pulse-reverse;
  }

  .flow-board--detailed .flow-line.reverse.active::after,
  .flow-board--detailed .flow-line.reverse.active {
    animation-direction: reverse;
  }

  .flow-board--summary .flow-line.reverse.active::after,
  .flow-board--summary .flow-line.reverse.active {
    animation-direction: reverse;
  }

  .flow-board--detailed .flow-line.forward.active::before {
    animation-name: jks-power-flow-pulse;
  }

  .flow-board--summary .flow-line.forward.active::before {
    animation-name: jks-power-flow-pulse;
  }

  .flow-board--detailed .flow-line.warning.active {
    --flow-rgb: 255, 196, 92;
  }

  .flow-board--detailed .flow-line.alert.active {
    --flow-rgb: 255, 106, 106;
  }

  .flow-board--detailed .line-pv1-inverter,
  .flow-board--detailed .line-pv2-inverter {
    --flow-rgb: 56, 239, 119;
    --flow-speed: 1.05s;
  }

  .flow-board--detailed .line-battery-inverter {
    --flow-rgb: 110, 224, 142;
    --flow-speed: 1.55s;
  }

  .flow-board--detailed .line-inverter-grid {
    --flow-rgb: 74, 163, 255;
    --flow-speed: 1.15s;
  }

  .flow-board--detailed .line-generator-inverter {
    --flow-rgb: 255, 191, 47;
    --flow-speed: 1.1s;
  }

  .flow-board--detailed .line-inverter-ups {
    --flow-rgb: 0, 216, 255;
    --flow-speed: 1.35s;
  }

  .flow-board--detailed .line-grid-load {
    --flow-rgb: 158, 184, 200;
    --flow-speed: 1.45s;
  }

  .flow-board--summary .line-pv-inverter {
    --flow-rgb: 56, 239, 119;
    --flow-speed: 1.1s;
    left: 50%;
    top: 28%;
    width: 15%;
    transform: rotate(90deg);
  }

  .flow-board--summary .line-inverter-grid {
    --flow-rgb: 74, 163, 255;
    --flow-speed: 1.18s;
    left: 26%;
    top: 51%;
    width: 22%;
  }

  .flow-board--summary .line-inverter-ups {
    --flow-rgb: 0, 216, 255;
    --flow-speed: 1.26s;
    left: 53%;
    top: 51%;
    width: 21%;
  }

  .flow-board--summary .line-battery-inverter {
    --flow-rgb: 110, 224, 142;
    --flow-speed: 1.5s;
    left: 50%;
    top: 65%;
    width: 15%;
    transform: rotate(90deg);
  }

  .flow-board--summary .line-grid-load {
    --flow-rgb: 74, 163, 255;
    --flow-speed: 1.38s;
    left: 17%;
    top: 63%;
    width: 11%;
    transform: rotate(90deg);
  }

  .flow-board--detailed .line-pv1-inverter {
    left: 34%;
    top: 24%;
    width: 21%;
    transform: rotate(38deg);
  }

  .flow-board--detailed .line-pv2-inverter {
    left: 66%;
    top: 24%;
    width: 20%;
    transform: rotate(141deg);
  }

  .flow-board--detailed .line-battery-inverter {
    left: 84%;
    top: 72%;
    width: 36%;
    transform: rotate(-150deg);
  }

  .flow-board--detailed .line-inverter-grid {
    left: 45%;
    top: 48%;
    width: 24%;
    transform: rotate(180deg);
  }

  .flow-board--detailed .line-generator-inverter {
    left: 50%;
    top: 72%;
    width: 24%;
    transform: rotate(-78deg);
  }

  .flow-board--detailed .line-inverter-ups {
    left: 65%;
    top: 48%;
    width: 25%;
  }

  .flow-board--detailed .line-grid-load {
    left: 14%;
    top: 52%;
    width: 23%;
    transform: rotate(90deg);
  }

  @keyframes jks-power-flow-pulse {
    0% { transform: translateX(-115%) scaleX(0.55); opacity: 0; }
    4% { transform: translateX(-100%) scaleX(0.62); opacity: 0.22; }
    8% { transform: translateX(-82%) scaleX(0.7); opacity: 0.55; }
    12% { transform: translateX(-66%) scaleX(0.76); opacity: 0.76; }
    18% { transform: translateX(-44%) scaleX(0.85); opacity: 1; }
    26% { transform: translateX(-12%) scaleX(0.94); opacity: 1; }
    34% { transform: translateX(18%) scaleX(1); opacity: 1; }
    42% { transform: translateX(50%) scaleX(1); opacity: 1; }
    50% { transform: translateX(80%) scaleX(1); opacity: 1; }
    58% { transform: translateX(112%) scaleX(1); opacity: 1; }
    66% { transform: translateX(142%) scaleX(1); opacity: 1; }
    74% { transform: translateX(176%) scaleX(0.98); opacity: 1; }
    82% { transform: translateX(204%) scaleX(0.95); opacity: 1; }
    88% { transform: translateX(236%) scaleX(0.86); opacity: 0.82; }
    92% { transform: translateX(260%) scaleX(0.78); opacity: 0.6; }
    96% { transform: translateX(292%) scaleX(0.66); opacity: 0.28; }
    100% { transform: translateX(320%) scaleX(0.55); opacity: 0; }
  }

  @keyframes jks-power-flow-pulse-reverse {
    0% { transform: translateX(320%) scaleX(0.55); opacity: 0; }
    4% { transform: translateX(292%) scaleX(0.66); opacity: 0.28; }
    8% { transform: translateX(260%) scaleX(0.78); opacity: 0.6; }
    12% { transform: translateX(236%) scaleX(0.86); opacity: 0.82; }
    18% { transform: translateX(204%) scaleX(0.95); opacity: 1; }
    26% { transform: translateX(176%) scaleX(0.98); opacity: 1; }
    34% { transform: translateX(142%) scaleX(1); opacity: 1; }
    42% { transform: translateX(112%) scaleX(1); opacity: 1; }
    50% { transform: translateX(80%) scaleX(1); opacity: 1; }
    58% { transform: translateX(50%) scaleX(1); opacity: 1; }
    66% { transform: translateX(18%) scaleX(1); opacity: 1; }
    74% { transform: translateX(-12%) scaleX(0.94); opacity: 1; }
    82% { transform: translateX(-44%) scaleX(0.85); opacity: 1; }
    88% { transform: translateX(-66%) scaleX(0.76); opacity: 0.76; }
    92% { transform: translateX(-82%) scaleX(0.7); opacity: 0.55; }
    96% { transform: translateX(-100%) scaleX(0.62); opacity: 0.22; }
    100% { transform: translateX(-115%) scaleX(0.55); opacity: 0; }
  }

  @keyframes jks-power-flow-base {
    from { background-position: -72px 0, 0 0; }
    to { background-position: 72px 0, 0 0; }
  }

  @keyframes jks-power-flow-texture {
    from { background-position: 0 0; }
    to { background-position: 44px 0; }
  }

  @media (prefers-reduced-motion: reduce) {
    .flow-board--detailed .flow-line.active::before,
    .flow-board--detailed .flow-line.active::after,
    .flow-board--summary .flow-line.active::before,
    .flow-board--summary .flow-line.active::after {
      animation: none;
    }

    .flow-board--detailed .flow-line.active::before,
    .flow-board--summary .flow-line.active::before {
      opacity: 0.75;
      transform: translateX(80%);
    }
  }

  .flow-lines {
    position: absolute;
    inset: 0;
    z-index: 0;
    pointer-events: none;
  }

  .flow {
    fill: none;
    stroke-width: 0.3;
    stroke-linecap: round;
    stroke-linejoin: round;
    filter: drop-shadow(0 0 1.2px currentColor);
  }

  .flow--green { color: var(--green); stroke: var(--green); }
  .flow--blue { color: var(--blue); stroke: var(--blue); }
  .flow--cyan { color: var(--cyan); stroke: var(--cyan); }
  .flow--amber { color: var(--amber); stroke: var(--amber); }

  .node {
    position: relative;
    z-index: 1;
    min-width: 0;
    overflow: hidden;
    padding: 14px;
  }

  .flow-board--detailed .node {
    padding: var(--detail-node-pad);
  }

  .node::before {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(circle at 50% 0%, var(--node-glow, transparent), transparent 60%);
    opacity: 0.75;
  }

  .node > * {
    position: relative;
    z-index: 1;
  }

  .node--pv,
  .node--pv-total {
    --node-glow: rgba(56, 239, 119, 0.16);
    border-color: rgba(56, 239, 119, 0.58);
  }

  .node--grid,
  .node--grid-load {
    --node-glow: rgba(74, 163, 255, 0.16);
    border-color: rgba(74, 163, 255, 0.58);
  }

  .node--inverter,
  .node--ups {
    --node-glow: rgba(0, 216, 255, 0.17);
    border-color: rgba(0, 216, 255, 0.58);
  }

  .node--generator {
    --node-glow: rgba(255, 191, 47, 0.16);
    border-color: rgba(255, 191, 47, 0.58);
  }

  .node--battery {
    --node-glow: rgba(56, 239, 119, 0.18);
    border-color: rgba(56, 239, 119, 0.58);
  }

  .energy-dashboard--detailed.is-pv1-offline .node--pv1,
  .energy-dashboard--detailed.is-pv2-offline .node--pv2,
  .energy-dashboard--detailed.is-grid-offline .node--grid,
  .energy-dashboard--detailed.is-grid-load-offline .node--grid-load,
  .energy-dashboard--detailed.is-ups-offline .node--ups,
  .energy-dashboard--detailed.is-generator-offline .node--generator,
  .energy-dashboard--detailed.is-battery-offline .node--battery {
    --node-glow: transparent;
    border-color: rgba(170, 185, 196, 0.26);
    background:
      linear-gradient(140deg, rgba(31, 42, 50, 0.72), rgba(5, 13, 18, 0.94));
    box-shadow: inset 0 0 30px rgba(255, 255, 255, 0.015);
  }

  .energy-dashboard--detailed.is-pv1-offline .node--pv1 .node-title,
  .energy-dashboard--detailed.is-pv2-offline .node--pv2 .node-title,
  .energy-dashboard--detailed.is-grid-offline .node--grid .node-title,
  .energy-dashboard--detailed.is-grid-load-offline .node--grid-load .node-title,
  .energy-dashboard--detailed.is-ups-offline .node--ups .node-title,
  .energy-dashboard--detailed.is-generator-offline .node--generator .node-title,
  .energy-dashboard--detailed.is-battery-offline .node--battery .battery-heading,
  .energy-dashboard--detailed.is-battery-offline .node--battery .battery-temp .icon {
    color: rgba(178, 191, 202, 0.72);
  }

  .energy-dashboard--detailed.is-pv1-offline .node--pv1 .power-readout strong,
  .energy-dashboard--detailed.is-pv2-offline .node--pv2 .power-readout strong,
  .energy-dashboard--detailed.is-grid-offline .node--grid .power-readout strong,
  .energy-dashboard--detailed.is-grid-load-offline .node--grid-load .power-readout strong,
  .energy-dashboard--detailed.is-ups-offline .node--ups .power-readout strong,
  .energy-dashboard--detailed.is-generator-offline .node--generator .power-readout strong,
  .energy-dashboard--detailed.is-generator-offline .node--generator .node-status,
  .energy-dashboard--detailed.is-battery-offline .node--battery .power-readout strong,
  .energy-dashboard--detailed.is-battery-offline .node--battery .battery-mode,
  .energy-dashboard--detailed.is-battery-offline .node--battery .battery-temp strong {
    color: rgba(178, 191, 202, 0.78);
  }

  .energy-dashboard--summary.is-pv-offline .node--pv-total,
  .energy-dashboard--summary.is-grid-offline .node--grid,
  .energy-dashboard--summary.is-grid-load-offline .node--grid-load,
  .energy-dashboard--summary.is-ups-offline .node--ups,
  .energy-dashboard--summary.is-battery-offline .node--battery {
    --node-glow: transparent;
    border-color: rgba(170, 185, 196, 0.26);
    background:
      linear-gradient(140deg, rgba(31, 42, 50, 0.72), rgba(5, 13, 18, 0.94));
    box-shadow: inset 0 0 30px rgba(255, 255, 255, 0.015);
  }

  .energy-dashboard--summary.is-pv-offline .node--pv-total .node-title,
  .energy-dashboard--summary.is-grid-offline .node--grid .node-title,
  .energy-dashboard--summary.is-grid-load-offline .node--grid-load .node-title,
  .energy-dashboard--summary.is-ups-offline .node--ups .node-title,
  .energy-dashboard--summary.is-battery-offline .node--battery .soc-ring,
  .energy-dashboard--summary.is-battery-offline .node--battery .battery-mode {
    color: rgba(178, 191, 202, 0.72);
  }

  .energy-dashboard--summary.is-pv-offline .node--pv-total .power-readout strong,
  .energy-dashboard--summary.is-grid-offline .node--grid .power-readout strong,
  .energy-dashboard--summary.is-grid-load-offline .node--grid-load .power-readout strong,
  .energy-dashboard--summary.is-ups-offline .node--ups .power-readout strong,
  .energy-dashboard--summary.is-battery-offline .node--battery .power-readout strong {
    color: rgba(178, 191, 202, 0.78);
  }

  .flow-board--summary .node--pv-total { grid-area: pv; }
  .flow-board--summary .node--grid { grid-area: grid; }
  .flow-board--summary .node--grid-load { grid-area: grid-load; }
  .flow-board--summary .summary-inverter { grid-area: inverter; }
  .flow-board--summary .node--ups { grid-area: load; }
  .flow-board--summary .summary-battery-node { grid-area: battery; }

  .energy-dashboard--summary {
    gap: 0;
    overflow: hidden;
  }

  .summary-scale-frame {
    width: 100%;
    min-width: 0;
    min-inline-size: 0;
    height: var(--summary-scaled-height, auto);
    overflow: hidden;
  }

  .summary-shell {
    width: 100%;
    min-width: 0;
    min-inline-size: 0;
    display: grid;
    grid-template-columns: minmax(164px, 214px) minmax(0, 1fr);
    gap: clamp(8px, 1cqw, 12px);
    align-items: stretch;
    height: clamp(380px, 34cqw, 380px);
  }

  .summary-chips {
    width: 100%;
    min-width: 0;
    min-inline-size: 0;
    max-width: 100%;
    max-inline-size: 100%;
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    grid-template-rows: repeat(6, minmax(0, 1fr));
    gap: 6px;
    overflow: hidden;
  }

  .energy-dashboard--summary .chip {
    min-height: 0;
    grid-template-columns: 34px minmax(0, 1fr);
    gap: 8px;
    padding: 7px 9px;
  }

  .energy-dashboard--summary .chip > .icon {
    width: 34px;
    height: 34px;
    padding: 7px;
  }

  .energy-dashboard--summary .chip__trend {
    display: none;
  }

  .energy-dashboard--summary .chip__label {
    font-size: clamp(9px, 0.72cqw, 11px);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .energy-dashboard--summary .chip__value {
    font-size: clamp(15px, 1.25cqw, 21px);
  }

  .flow-board--summary .node {
    min-height: 82px;
    padding: 10px;
  }

  .flow-board--summary .summary-node {
    display: grid;
    align-content: center;
  }

  .flow-board--summary .node-title {
    grid-template-columns: 34px minmax(0, 1fr);
    gap: 8px;
    margin-bottom: 7px;
  }

  .flow-board--summary .node-title .icon {
    width: 32px;
    height: 32px;
    font-size: 32px;
  }

  .flow-board--summary .node h3 {
    font-size: clamp(14px, 1.12cqw, 18px);
  }

  .flow-board--summary .power-readout {
    grid-template-columns: minmax(0, 1fr) auto;
    align-items: center;
    gap: 7px;
    margin-top: 0;
    padding-top: 7px;
  }

  .flow-board--summary .power-readout > span {
    color: var(--muted);
    white-space: nowrap;
  }

  .flow-board--summary .power-readout strong {
    justify-content: flex-end;
    font-size: clamp(19px, 1.75cqw, 27px);
  }

  .flow-board--summary .node-status {
    margin-top: 6px;
    padding-top: 6px;
    font-size: clamp(10px, 0.82cqw, 12px);
  }

  .summary-inverter {
    min-height: 158px;
    display: grid;
    gap: 0;
    align-content: center;
    padding: clamp(11px, 1.2cqw, 15px);
  }

  .summary-inverter__head {
    display: grid;
    grid-template-columns: 46px minmax(0, 1fr);
    gap: 10px;
    align-items: center;
  }

  .summary-inverter__head .icon {
    width: 42px;
    height: 42px;
    padding: 8px;
    border-radius: 8px;
    color: var(--cyan);
    background: rgba(0, 216, 255, 0.1);
    box-shadow: 0 0 18px rgba(0, 216, 255, 0.18);
  }

  .summary-inverter__head h2 {
    font-size: clamp(18px, 1.5cqw, 24px);
    line-height: 1;
  }

  .summary-inverter__head span {
    display: block;
    margin-top: 4px;
    color: var(--green);
    font-weight: 700;
  }

  .summary-inverter__power {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 7px;
  }

  .summary-inverter__power .power-readout {
    min-width: 0;
    padding: 8px 10px;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.04);
    overflow: hidden;
  }

  .summary-inverter-readout {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    align-content: center;
    margin-top: 0;
    padding-top: 0;
    gap: 5px;
  }

  .flow-board--summary .summary-inverter-readout {
    grid-template-columns: minmax(0, 1fr);
  }

  .summary-readout-main {
    min-width: 0;
    display: grid;
    grid-template-columns: 16px minmax(0, 1fr);
    align-items: center;
    gap: 5px;
  }

  .summary-readout-main .icon {
    width: 16px;
    height: 16px;
  }

  .summary-readout-main strong {
    min-width: 0;
    justify-content: flex-start;
    gap: 3px;
    overflow: visible;
    font-size: clamp(13px, 1.18cqw, 17px);
  }

  .summary-readout-main strong span,
  .summary-readout-main strong small {
    flex: 0 0 auto;
  }

  .summary-readout-meta {
    min-width: 0;
    min-height: 18px;
    display: grid;
    grid-template-columns: 16px minmax(0, 1fr);
    align-items: center;
    justify-content: flex-start;
    gap: 5px;
    padding-top: 5px;
    border-top: 1px solid var(--line);
    color: var(--green);
  }

  .summary-readout-meta .icon {
    width: 16px;
    height: 16px;
  }

  .summary-readout-meta--cyan .icon {
    color: var(--cyan);
  }

  .summary-readout-meta--green .icon {
    color: var(--green);
  }

  .summary-readout-meta strong {
    min-width: 0;
    overflow: hidden;
    white-space: nowrap;
    font-size: clamp(11px, 0.92cqw, 14px);
  }

  .flow-board--summary .summary-battery {
    gap: 10px;
  }

  .flow-board--summary .summary-battery .soc-ring {
    width: clamp(74px, 6cqw, 80px);
  }

  .summary-battery .battery-icon-stack {
    width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    margin-bottom: 0;
  }

  .summary-battery__data {
    min-width: 0;
    display: grid;
    gap: 0;
  }

  .flow-board--summary .summary-battery__data .power-readout {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    padding-inline: 0 10px;
  }

  .summary-battery__stats {
    display: grid;
    gap: 4px;
  }

  .flow-board--summary .summary-battery__stats .power-readout {
    min-height: 24px;
    display: grid;
    grid-template-columns: 17px minmax(0, 1fr) auto;
    gap: 6px;
    align-items: center;
    margin-top: 0;
    padding: 5px 10px 0 0;
    border-top: 1px solid var(--line);
    color: var(--muted);
  }

  .summary-battery__stats .icon {
    width: 16px;
    height: 16px;
    color: var(--green);
  }

  .summary-battery__stats .power-readout > span {
    font-size: clamp(10px, 0.82cqw, 12px);
  }

  .summary-battery__stats .power-readout strong {
    justify-content: flex-end;
    color: var(--green);
    font-size: clamp(11px, 0.92cqw, 14px);
  }

  @media (min-width: 1025px) {
    .energy-dashboard--summary .summary-shell {
      transform: scale(var(--summary-scale, 1));
      transform-origin: top left;
    }
  }

  h2,
  h3,
  p {
    margin: 0;
  }

  .node-title {
    display: grid;
    grid-template-columns: 46px minmax(0, 1fr);
    gap: 12px;
    align-items: center;
    margin-bottom: 11px;
  }

  .node-title .icon {
    width: 44px;
    height: 44px;
    font-size: 44px;
  }

  .flow-board--detailed .node-title {
    grid-template-columns: var(--detail-icon-size) minmax(0, 1fr);
    gap: 9px;
    margin-bottom: 8px;
  }

  .flow-board--detailed .node-title .icon {
    width: var(--detail-icon-size);
    height: var(--detail-icon-size);
    font-size: var(--detail-icon-size);
  }

  .node--pv .node-title,
  .node--pv-total .node-title,
  .node--battery .node-title { color: var(--green); }
  .node--grid .node-title,
  .node--grid-load .node-title { color: var(--blue); }
  .node--inverter .node-title,
  .node--ups .node-title { color: var(--cyan); }
  .node--generator .node-title { color: var(--amber); }

  .node h3,
  .system-panel h3 {
    color: #f4f8ff;
    font-size: clamp(15px, 1.2cqw, 22px);
    font-weight: 700;
    line-height: 1.05;
  }

  .flow-board--detailed .node h3 {
    font-size: var(--detail-title-size);
  }

  .node p {
    margin-top: 3px;
    color: var(--muted);
    font-size: clamp(10px, 0.82cqw, 13px);
  }

  .flow-board--detailed .node p {
    font-size: var(--detail-copy-size);
  }

  .metric-line,
  .phase-row {
    display: grid;
    grid-template-columns: auto minmax(0, 1fr);
    gap: 10px;
    align-items: baseline;
    color: var(--muted);
    font-size: clamp(11px, 0.9cqw, 15px);
    line-height: 1.5;
  }

  .flow-board--detailed .metric-line,
  .flow-board--detailed .phase-row {
    align-items: center;
    gap: 8px;
    font-size: var(--detail-copy-size);
    line-height: 1.38;
  }

  .flow-board--detailed .metric-line,
  .flow-board--detailed .phase-row,
  .flow-board--detailed .power-readout,
  .flow-board--detailed .node-status {
    min-height: 31px;
    border-top: 1px solid var(--line);
  }

  .flow-board--detailed .phase-row {
    padding-block: 0;
  }

  .metric-line strong,
  .phase-row strong {
    min-width: 0;
    color: rgba(244, 248, 255, 0.9);
    font-weight: 500;
    text-align: right;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .flow-board--detailed .metric-line strong,
  .flow-board--detailed .phase-row strong {
    overflow: visible;
    text-overflow: clip;
  }

  .phase-row {
    margin-top: 9px;
  }

  .flow-board--detailed .phase-row {
    margin-top: 0;
  }

  .power-readout {
    display: grid;
    gap: 5px;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid var(--line);
    color: var(--muted);
    font-size: clamp(11px, 0.9cqw, 15px);
  }

  .flow-board--detailed .power-readout {
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 8px;
    align-items: center;
    margin-top: 0;
    padding-top: 0;
    font-size: var(--detail-copy-size);
  }

  .flow-board--detailed .power-readout > span {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .power-readout strong {
    display: flex;
    align-items: baseline;
    gap: 6px;
    color: #f4f8ff;
    font-size: clamp(21px, 1.8cqw, 32px);
    font-weight: 600;
    line-height: 1;
    white-space: nowrap;
  }

  .flow-board--detailed .power-readout strong {
    align-items: center;
    gap: 5px;
    justify-content: flex-end;
    font-size: var(--detail-value-size);
  }

  .power-readout small {
    font-size: 0.62em;
    font-weight: 500;
  }

  .power-readout--green strong,
  .battery-mode { color: var(--green); }
  .power-readout--blue strong { color: var(--blue); }
  .power-readout--cyan strong { color: var(--cyan); }
  .power-readout--amber strong { color: var(--amber); }

  .flow-board--detailed .battery-mode {
    min-height: 30px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    border-top: 1px solid var(--line);
    font-size: var(--detail-copy-size);
    font-weight: 700;
    text-align: right;
  }

  .node-status {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid var(--line);
    font-size: clamp(12px, 0.95cqw, 16px);
    font-weight: 600;
  }

  .flow-board--detailed .node-status {
    gap: 7px;
    margin-top: 0;
    padding-top: 0;
    font-size: clamp(10px, 0.82cqw, 13px);
  }

  .node-status .icon {
    width: 22px;
    height: 22px;
  }

  .node-status--blue { color: var(--blue); }
  .node-status--amber { color: var(--amber); }

  .inverter-heading {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 18px;
    margin-bottom: 14px;
  }

  .inverter-heading .icon {
    width: 58px;
    height: 58px;
    font-size: 58px;
    padding: 10px;
    border: 1px solid rgba(0, 216, 255, 0.5);
    border-radius: 8px;
    color: var(--cyan);
    background: rgba(0, 148, 255, 0.12);
    box-shadow: 0 0 20px rgba(0, 216, 255, 0.22);
  }

  .inverter-heading h2 {
    font-size: clamp(22px, 1.8cqw, 30px);
    font-weight: 700;
  }

  .inverter-kpis {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 44px minmax(0, 1fr);
    gap: 12px;
    align-items: center;
  }

  .inverter-kpis .power-readout {
    margin: 0;
    padding: 10px 12px;
    border: 1px solid rgba(255, 255, 255, 0.065);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.035);
    text-align: center;
  }

  .inverter-kpis .power-readout strong {
    justify-content: center;
  }

  .sync-icon {
    width: 38px;
    height: 38px;
    color: var(--cyan);
    justify-self: center;
  }

  .inverter-lines {
    display: grid;
    max-width: 430px;
    margin: 14px auto 0;
  }

  .inverter-footer {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
    margin-top: 14px;
    padding-top: 14px;
    border-top: 1px solid var(--line);
  }

  .inverter-footer > div {
    display: grid;
    grid-template-columns: 30px minmax(0, 1fr);
    grid-template-areas: "icon label" "icon value";
    column-gap: 10px;
    align-items: center;
  }

  .inverter-footer .icon { grid-area: icon; width: 28px; height: 28px; color: var(--cyan); }
  .inverter-footer span { grid-area: label; color: var(--muted); font-size: clamp(10px, 0.8cqw, 14px); }
  .inverter-footer strong { grid-area: value; color: var(--cyan); font-size: clamp(13px, 0.95cqw, 18px); }
  .inverter-footer div:last-child .icon,
  .inverter-footer div:last-child strong { color: var(--green); }

  .flow-board--detailed .node--inverter {
    padding: 0;
    min-height: 222px;
  }

  .flow-board--detailed .inverter-layout {
    min-height: 100%;
    display: grid;
    grid-template-columns: minmax(172px, 0.86fr) minmax(246px, 1.14fr);
  }

  .flow-board--detailed .inverter-left,
  .flow-board--detailed .inverter-right {
    min-width: 0;
    padding: 12px;
  }

  .flow-board--detailed .inverter-left {
    display: grid;
    gap: 9px;
    align-content: center;
    border-right: 1px solid var(--line);
    background: rgba(0, 216, 255, 0.045);
  }

  .flow-board--detailed .inverter-right {
    display: grid;
    align-content: center;
  }

  .flow-board--detailed .inverter-state {
    min-width: 0;
    display: grid;
    grid-template-columns: 70px minmax(0, 1fr);
    gap: 14px;
    align-items: center;
    padding: 11px 13px;
    border: 1px solid rgba(56, 239, 119, 0.22);
    border-radius: 8px;
    background: rgba(56, 239, 119, 0.07);
  }

  .flow-board--detailed .inverter-state .icon {
    width: 50px;
    height: 50px;
    font-size: 30px;
    padding: 10px;
    border-radius: 8px;
    color: var(--green);
    background: rgba(56, 239, 119, 0.11);
    box-shadow: 0 0 16px rgba(56, 239, 119, 0.18);
  }

  .flow-board--detailed .inverter-state > div {
    min-width: 0;
  }

  .flow-board--detailed .inverter-state span {
    display: block;
    color: var(--muted);
    font-size: var(--detail-copy-size);
    line-height: 1.25;
  }

  .flow-board--detailed .inverter-state strong {
    display: block;
    margin-top: 4px;
    color: var(--green);
    font-size: clamp(15px, 1cqw, 19px);
    font-weight: 700;
    line-height: 1.1;
    white-space: nowrap;
  }

  .flow-board--detailed .inverter-kpis {
    grid-template-columns: 1fr;
    gap: 8px;
    align-items: stretch;
  }

  .flow-board--detailed .inverter-kpis .power-readout {
    min-height: 46px;
    gap: 10px;
    text-align: left;
  }

  .flow-board--detailed .inverter-heading {
    display: block;
    margin: 0 0 11px;
    text-align: left;
  }

  .flow-board--detailed .inverter-heading h2 {
    font-size: clamp(18px, 1.26cqw, 24px);
    line-height: 1;
  }

  .flow-board--detailed .inverter-heading span {
    display: block;
    margin-top: 5px;
    color: var(--muted);
    font-size: var(--detail-copy-size);
    font-weight: 600;
  }

  .flow-board--detailed .inverter-lines {
    max-width: none;
    margin: 0;
    gap: 0;
  }

  .flow-board--detailed .inverter-lines .metric-line {
    min-height: 29px;
    align-items: center;
    border-top: 1px solid var(--line);
  }

  .flow-board--detailed .inverter-lines .metric-line:first-child {
    border-top-color: rgba(255, 255, 255, 0.2);
  }

  .battery-heading {
    text-align: center;
    margin-bottom: 10px;
  }

  .battery-grid {
    display: grid;
    grid-template-columns: auto minmax(0, 1fr);
    gap: 12px;
    align-items: center;
  }

  .soc-ring {
    --soc-color: var(--green);
    --soc-track: rgba(239, 248, 255, 0.13);
    width: clamp(92px, 7.6cqw, 120px);
    aspect-ratio: 1;
    display: grid;
    place-items: center;
    border: 6px solid var(--soc-track);
    border-radius: 50%;
    color: #f4f8ff;
    box-shadow: 0 0 18px color-mix(in srgb, var(--soc-color) 24%, transparent);
  }

  .is-battery-empty .soc-ring { --soc-color: var(--red); }
  .is-battery-low .soc-ring { --soc-color: var(--amber); }
  .is-battery-half .soc-ring { --soc-color: #b8ef38; }
  .is-battery-full .soc-ring,
  .is-battery-charging .soc-ring { --soc-color: var(--green); }

  .is-battery-q1 .soc-ring { border-top-color: var(--soc-color); }
  .is-battery-q2 .soc-ring { border-right-color: var(--soc-color); }
  .is-battery-q3 .soc-ring { border-bottom-color: var(--soc-color); }
  .is-battery-q4 .soc-ring { border-left-color: var(--soc-color); }

  .battery-icon-stack {
    width: 36px;
    height: 30px;
    display: grid;
    place-items: center;
    margin-bottom: -14px;
  }

  .battery-icon-stack .icon {
    grid-area: 1 / 1;
    width: 31px;
    height: 31px;
    font-size: 31px;
    color: var(--soc-color);
    display: none;
  }

  .is-battery-charging .battery-icon-stack .icon--batteryBolt,
  .is-battery-empty:not(.is-battery-charging) .battery-icon-stack .icon--batteryEmpty,
  .is-battery-low:not(.is-battery-charging) .battery-icon-stack .icon--batteryLow,
  .is-battery-half:not(.is-battery-charging) .battery-icon-stack .icon--batteryHalf,
  .is-battery-full:not(.is-battery-charging) .battery-icon-stack .icon--batteryFull {
    display: inline-grid;
  }

  .soc-ring strong {
    display: flex;
    align-items: baseline;
    font-size: clamp(24px, 2cqw, 34px);
    line-height: 0.8;
  }

  .soc-ring small { font-size: 0.55em; }
  .soc-ring > span:last-child { font-size: 12px; font-weight: 650; }

  .battery-temp {
    grid-column: 1 / -1;
    display: flex;
    align-items: center;
    gap: 7px;
    padding-top: 8px;
    border-top: 1px solid var(--line);
    color: var(--muted);
  }

  .battery-temp .icon,
  .summary-temp .icon { width: 24px; height: 24px; color: var(--green); }
  .battery-temp strong,
  .summary-temp strong { color: var(--green); }

  .summary-battery {
    height: 100%;
    display: grid;
    grid-template-columns: auto minmax(0, 1fr) auto;
    gap: 18px;
    align-items: center;
  }

  .summary-battery .power-readout {
    margin: 0;
    padding: 0 18px;
    border-top: 0;
    border-left: 1px solid var(--line);
    border-right: 1px solid var(--line);
  }

  .summary-temp {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .system-panel {
    display: grid;
    gap: 12px;
    padding: 14px 16px;
  }

  .energy-dashboard--detailed > .system-panel {
    order: -1;
    gap: 8px;
    padding: 10px 12px;
  }

  .system-panel header {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .system-panel header .icon {
    width: 28px;
    height: 28px;
    color: rgba(239, 248, 255, 0.74);
  }

  .energy-dashboard--detailed .system-panel header .icon {
    width: 22px;
    height: 22px;
  }

  .system-panel header h3 {
    flex: 1;
  }

  .online {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: var(--green);
    font-weight: 600;
  }

  .energy-dashboard--detailed .online {
    font-size: var(--detail-copy-size);
  }

  .online i {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: var(--green);
    box-shadow: 0 0 12px var(--green);
  }

  .system-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 0 18px;
  }

  .system-grid > div {
    min-width: 0;
    min-height: 38px;
    display: grid;
    grid-template-columns: 26px minmax(0, 1fr) auto;
    gap: 10px;
    align-items: center;
    border-top: 1px solid var(--line);
    color: var(--muted);
    font-size: clamp(11px, 0.86cqw, 15px);
  }

  .energy-dashboard--detailed .system-grid {
    gap: 0 14px;
  }

  .energy-dashboard--detailed .system-grid > div {
    min-height: 30px;
    grid-template-columns: 22px minmax(0, 1fr) auto;
    gap: 8px;
    font-size: var(--detail-copy-size);
  }

  .system-grid .icon {
    width: 22px;
    height: 22px;
    color: var(--cyan);
  }

  .energy-dashboard--detailed .system-grid .icon {
    width: 18px;
    height: 18px;
  }

  .system-grid strong {
    color: rgba(244, 248, 255, 0.92);
    font-weight: 500;
    white-space: nowrap;
  }

  .system-panel footer {
    display: flex;
    align-items: center;
    gap: 8px;
    color: rgba(239, 248, 255, 0.46);
    font-size: clamp(12px, 0.9cqw, 15px);
  }

  .energy-dashboard--detailed .system-panel footer {
    font-size: var(--detail-copy-size);
  }

  .system-panel footer .icon {
    width: 20px;
    height: 20px;
  }

  .helper,
  .entity-map {
    border-radius: 8px;
    background: rgba(7, 24, 40, 0.88);
    border: 1px solid rgba(162, 221, 255, 0.14);
    padding: 10px 12px;
    font-size: clamp(10px, 1.25cqw, 12px);
    line-height: 1.45;
  }

  .helper--warn { color: #ffcf66; }

  .entity-map {
    display: grid;
    gap: 7px;
  }

  .entity-row {
    display: grid;
    grid-template-columns: minmax(0, 180px) minmax(0, 1fr);
    gap: 12px;
    font-family: Consolas, "Courier New", monospace;
  }

  .entity-row span:last-child {
    overflow-wrap: anywhere;
    color: rgba(239, 248, 255, 0.8);
  }

  @container (max-width: 1024px) {
    .card-shell {
      padding: 10px;
    }

    .energy-dashboard--detailed {
      --detail-card-gap: 14px;
      --detail-row-gap: 14px;
      --detail-node-pad: 11px;
      --detail-icon-size: 36px;
      --detail-title-size: 18px;
      --detail-copy-size: 13px;
      --detail-value-size: 24px;
    }

    .detailed-shell {
      grid-template-columns: 1fr;
      gap: 14px;
    }

    .sidebar-chips {
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 146px), 1fr));
      grid-template-rows: none;
      gap: 8px;
    }

    .chip-row,
    .badge-row {
      grid-template-columns: repeat(auto-fit, minmax(166px, 1fr));
    }

    .flow-lines {
      display: none;
    }

    .flow-scale-frame {
      position: relative;
      width: 100%;
      height: var(--flow-scaled-height, auto);
      overflow: hidden;
    }

    .detail-flow-lines {
      display: block;
    }

    .flow-board--detailed {
      position: absolute;
      top: 0;
      left: 0;
      display: grid;
      width: 1024px;
      max-width: none;
      grid-template-columns: minmax(0, 1.04fr) minmax(0, 0.96fr);
      grid-template-areas:
        "pv1 pv2"
        "inverter ups"
        "inverter generator"
        "grid battery"
        "grid-load battery";
      grid-auto-rows: minmax(0, auto);
      min-height: 0;
      gap: 16px;
      overflow: visible;
      transform: scale(var(--flow-scale, 1));
      transform-origin: top left;
    }

    .flow-row,
    .flow-row--middle,
    .flow-row--bottom {
      display: contents;
    }

    .flow-board--detailed .node--pv1 { grid-area: pv1; }
    .flow-board--detailed .node--pv2 { grid-area: pv2; }
    .flow-board--detailed .node--inverter { grid-area: inverter; }
    .flow-board--detailed .node-slot--ups { grid-area: ups; }
    .flow-board--detailed .node-slot--grid { grid-area: grid; }
    .flow-board--detailed .node--generator { grid-area: generator; }
    .flow-board--detailed .node--battery { grid-area: battery; }
    .flow-board--detailed .node--grid-load { grid-area: grid-load; }

    .flow-board--detailed .node,
    .flow-board--detailed .node-slot {
      min-height: 0;
    }

    .flow-board--detailed .node-slot {
      display: grid;
      align-content: stretch;
    }

    .flow-board--detailed .node-slot > .node {
      min-height: 100%;
    }

    .flow-board--detailed .inverter-layout {
      grid-template-columns: 1fr;
    }

    .flow-board--detailed .inverter-left {
      border-right: 0;
      border-bottom: 1px solid var(--line);
    }

    .flow-board--detailed .inverter-kpis {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .flow-board--detailed .inverter-state {
      grid-template-columns: 56px minmax(0, 1fr);
    }

    .flow-board--detailed .inverter-state .icon {
      width: 48px;
      height: 48px;
    }

    .flow-board--detailed .metric-line,
    .flow-board--detailed .phase-row {
      grid-template-columns: minmax(0, 0.86fr) minmax(0, 1.14fr);
    }

    .flow-board--detailed .metric-line strong,
    .flow-board--detailed .phase-row strong {
      white-space: normal;
      overflow-wrap: anywhere;
      line-height: 1.24;
    }

    .flow-board--detailed .power-readout {
      grid-template-columns: minmax(0, 0.86fr) minmax(0, 1.14fr);
    }

    .flow-board--detailed .power-readout strong {
      min-width: 0;
    }

    .flow-board--detailed .node--battery {
      display: grid;
      grid-template-rows: auto minmax(0, 1fr);
    }

    .flow-board--detailed .battery-grid {
      min-height: 100%;
      grid-template-columns: minmax(0, 1fr);
      grid-template-rows: auto auto minmax(196px, 1fr);
      grid-template-areas:
        "battery-data"
        "battery-temp"
        "battery-soc";
      align-items: start;
    }

    .flow-board--detailed .battery-data {
      grid-area: battery-data;
    }

    .flow-board--detailed .battery-temp {
      grid-area: battery-temp;
    }

    .flow-board--detailed .soc-ring {
      grid-area: battery-soc;
      align-self: end;
      justify-self: center;
      width: 190px;
      border-width: 8px;
      margin-top: 24px;
      margin-bottom: 24px;
    }

    .flow-board--detailed .soc-ring strong {
      font-size: 46px;
    }

    .flow-board--detailed .soc-ring > span:last-child {
      font-size: 15px;
    }

    .flow-board--detailed .battery-icon-stack {
      width: 50px;
      height: 42px;
      margin-bottom: -18px;
    }

    .flow-board--detailed .battery-icon-stack .icon {
      width: 42px;
      height: 42px;
      font-size: 42px;
    }

    .flow-board--detailed .line-pv1-inverter {
      left: 23%;
      top: 17%;
      width: 23%;
      transform: rotate(55deg);
    }

    .flow-board--detailed .line-pv2-inverter {
      left: 74%;
      top: 17%;
      width: 34%;
      transform: rotate(153deg);
    }

    .flow-board--detailed .line-inverter-ups {
      left: 46%;
      top: 37%;
      width: 10%;
    }

    .flow-board--detailed .line-generator-inverter {
      left: 57%;
      top: 52%;
      width: 13%;
      transform: rotate(180deg);
    }

    .flow-board--detailed .line-battery-inverter {
      left: 73%;
      top: 68%;
      width: 39%;
      transform: rotate(-160deg);
    }

    .flow-board--detailed .line-inverter-grid {
      left: 25%;
      top: 57%;
      width: 12%;
      transform: rotate(90deg);
    }

    .flow-board--detailed .line-grid-load {
      left: 25%;
      top: 79%;
      width: 12%;
      transform: rotate(90deg);
    }

    .system-grid {
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    }

    .chip {
      min-height: 72px;
      grid-template-columns: 44px minmax(0, 1fr) 24px;
      padding: 10px;
    }

    .chip > .icon {
      width: 42px;
      height: 42px;
      padding: 8px;
    }

    .sync-icon {
      display: none;
    }

    .summary-battery .power-readout {
      padding: 12px 0;
      border-left: 0;
      border-right: 0;
      border-top: 1px solid var(--line);
    }
  }

  @media (max-width: 767px) {
    .energy-dashboard--detailed {
      --detail-card-gap: 12px;
      --detail-row-gap: 12px;
      --detail-node-pad: 12px;
      --detail-icon-size: 38px;
      --detail-title-size: 18px;
      --detail-copy-size: 13px;
      --detail-value-size: 24px;
    }

    .energy-dashboard--detailed .sidebar-chips {
      grid-template-columns: minmax(0, 1fr);
      gap: 8px;
    }

    .energy-dashboard--detailed .side-rail,
    .energy-dashboard--detailed .sidebar-chips,
    .energy-dashboard--detailed .side-rail .chip {
      max-width: 100%;
      min-width: 0;
    }

    .energy-dashboard--detailed .side-rail .chip {
      width: 100%;
      min-height: 56px;
      grid-template-columns: 32px minmax(0, 1fr);
      align-items: center;
      padding: 8px 12px;
    }

    .energy-dashboard--detailed .side-rail .chip__content {
      max-width: 100%;
      min-width: 0;
      grid-template-columns: minmax(0, 1fr);
      gap: 4px;
      overflow: visible;
    }

    .energy-dashboard--detailed .side-rail .chip__value {
      min-width: 0;
      margin-top: 0;
      justify-content: flex-start;
      overflow: visible;
    }

    .energy-dashboard--detailed .flow-scale-frame {
      position: relative;
      height: auto;
      overflow: visible;
    }

    .energy-dashboard--detailed .detail-flow-lines {
      display: none;
    }

    .energy-dashboard--detailed .flow-board--detailed {
      position: relative;
      top: auto;
      left: auto;
      width: 100%;
      max-width: 100%;
      grid-template-columns: minmax(0, 1fr);
      grid-template-areas:
        "pv1"
        "pv2"
        "grid"
        "generator"
        "battery"
        "inverter"
        "ups"
        "grid-load";
      gap: 12px;
      transform: none;
      overflow: visible;
    }

    .energy-dashboard--detailed .flow-board--detailed .node-slot,
    .energy-dashboard--detailed .flow-board--detailed .node-slot > .node {
      min-height: 0;
    }

    .energy-dashboard--detailed .flow-board--detailed .inverter-kpis .power-readout {
      gap: 5px;
    }

    .energy-dashboard--detailed .flow-board--detailed .power-readout strong {
      min-width: 0;
      overflow-wrap: anywhere;
      white-space: normal;
    }
  }

  @media (max-width: 1024px) {
    .energy-dashboard--summary .summary-shell {
      grid-template-columns: 1fr;
      gap: 8px;
      height: auto;
      min-height: 0;
    }

    .energy-dashboard--summary .summary-chips {
      grid-template-columns: repeat(2, minmax(0, 1fr));
      grid-template-rows: none;
      gap: 8px;
    }

    .energy-dashboard--summary .chip {
      grid-template-columns: 38px minmax(0, 1fr);
      gap: 8px;
      padding: 8px;
      overflow: hidden;
    }

    .energy-dashboard--summary .chip > .icon {
      width: 36px;
      height: 36px;
      padding: 7px;
    }

    .energy-dashboard--summary .chip__trend {
      width: 18px;
      height: 18px;
    }

    .energy-dashboard--summary .chip__value {
      gap: 4px;
      font-size: clamp(16px, 4.8cqw, 22px);
      overflow: hidden;
      text-overflow: clip;
    }

    .flow-board--summary {
      grid-template-columns: repeat(2, minmax(0, 1fr));
      grid-template-rows: none;
      grid-template-areas:
        "pv inverter"
        "grid inverter"
        "grid-load load"
        "battery battery";
      height: auto;
      min-height: auto;
      gap: 8px;
      padding: 0;
      overflow: hidden;
    }

    .flow-board--summary .summary-flow-lines {
      display: none;
    }

    .flow-board--summary .summary-inverter {
      min-height: 100%;
    }

    .flow-board--summary .node,
    .flow-board--summary .summary-inverter,
    .flow-board--summary .summary-inverter__head,
    .flow-board--summary .summary-battery,
    .flow-board--summary .summary-battery__data {
      min-width: 0;
    }

    .flow-board--summary .node {
      padding: 10px;
    }

    .flow-board--summary .node-title {
      grid-template-columns: 34px minmax(0, 1fr);
      gap: 8px;
    }

    .flow-board--summary .node-title .icon {
      width: 32px;
      height: 32px;
      font-size: 32px;
    }

    .flow-board--summary .summary-inverter__head {
      grid-template-columns: 46px minmax(0, 1fr);
      gap: 10px;
    }

    .flow-board--summary .summary-inverter__head .icon {
      width: 42px;
      height: 42px;
      padding: 8px;
    }

    .flow-board--summary .summary-inverter__head h2 {
      font-size: clamp(19px, 5.8cqw, 26px);
    }

    .flow-board--summary .summary-inverter__power {
      grid-template-columns: 1fr;
    }

    .flow-board--summary .summary-battery {
      grid-template-columns: auto minmax(0, 1fr);
      gap: 8px;
    }

    .flow-board--summary .summary-battery .soc-ring {
      width: 78px;
      border-width: 5px;
    }

    .flow-board--summary .summary-battery .battery-icon-stack {
      width: 30px;
      height: 30px;
      display: grid;
      place-items: center;
      margin-bottom: 0;
    }

    .flow-board--summary .summary-battery .battery-icon-stack .icon {
      width: 24px;
      height: 24px;
      font-size: 24px;
    }

    .flow-board--summary .summary-battery .soc-ring strong {
      font-size: 23px;
    }

    .flow-board--summary .summary-battery .soc-ring > span:last-child {
      font-size: 10px;
    }

    .flow-board--summary .summary-battery__data .power-readout {
      grid-template-columns: 1fr;
      gap: 5px;
      padding: 0;
      border-left: 0;
      border-right: 0;
    }

    .flow-board--summary .summary-battery__data .power-readout strong {
      font-size: clamp(18px, 5.4cqw, 24px);
    }

    .flow-board--summary .summary-battery__stats .power-readout {
      grid-template-columns: 17px minmax(0, 1fr) auto;
      gap: 6px;
      padding: 5px 0 0;
    }

    .flow-board--summary .summary-battery__stats .power-readout strong {
      font-size: clamp(12px, 3.4cqw, 15px);
    }

    .flow-board--summary .battery-mode {
      padding-right: 0;
    }
  }
`;
class he extends HTMLElement {
  renderer;
  rootNode;
  config;
  hassValue;
  resolved = {};
  attemptedEntityKeys = /* @__PURE__ */ new Set();
  hasRendered = !1;
  constructor() {
    super(), this.rootNode = this.attachShadow({ mode: "open" }), this.renderer = new Wr(this.rootNode);
  }
  setConfig(r) {
    if (!r || typeof r != "object")
      throw new Error("Card configuration is required");
    this.config = {
      ...this.defaultConfig,
      ...r,
      entities: {
        ...this.defaultConfig.entities ?? {},
        ...r.entities ?? {}
      }
    }, this.resolved = {}, this.attemptedEntityKeys.clear(), this.hasRendered = !1, this.resolveEntities(!0), this.render();
  }
  set hass(r) {
    if (this.activeConfig.static && this.hasRendered) {
      this.hassValue = r;
      return;
    }
    this.hassValue = r, this.resolveEntities(), this.render();
  }
  connectedCallback() {
    this.render();
  }
  disconnectedCallback() {
  }
  getCardSize() {
    return this.defaultCardSize;
  }
  static getStubConfig() {
    return { type: "custom:jks-detailed" };
  }
  get activeConfig() {
    return this.config ?? this.defaultConfig;
  }
  resolveEntities(r = !1) {
    if (!this.hassValue) return;
    r && this.attemptedEntityKeys.clear();
    const e = r ? ie : ie.filter((o) => {
      if (!this.attemptedEntityKeys.has(o)) return !0;
      const n = this.resolved[o];
      return !n || !this.hassValue?.states[n];
    });
    if (e.length) {
      this.resolved = {
        ...this.resolved,
        ...Pe(this.hassValue, this.activeConfig.entities, e)
      };
      for (const o of e) this.attemptedEntityKeys.add(o);
    }
  }
  render() {
    const r = this.activeConfig, e = Ir((n) => this.readValue(n), {
      batteryNegativeIsCharging: r.battery_negative_is_charging !== !1
    }), o = !r.static && e.missing.length ? `Missing critical sensors: ${e.missing.join(", ")}` : "";
    this.renderer.render(this.variant, {
      title: r.title?.trim() ?? "",
      values: e.values,
      flags: e.flags,
      warning: o,
      entityRows: r.show_entity_map ? this.entityRows() : void 0
    }), this.hasRendered = !0;
  }
  readValue(r) {
    return this.activeConfig.static ? Rr(r) : r === "daily_cost" ? null : Xe(this.hassValue, this.resolved, r);
  }
  entityRows() {
    return Object.entries(this.resolved).map(([r, e]) => [r, e ?? "--"]);
  }
}
const ye = (t) => {
  window.customCards = window.customCards || [];
  const r = window.customCards.find((e) => e.type === t.tag);
  if (r) {
    r.name = t.name, r.description = t.description;
    return;
  }
  window.customCards.push({
    type: t.tag,
    name: t.name,
    description: t.description
  });
}, O = "jks-detailed";
class tt extends he {
  variant = "detailed";
  defaultCardSize = 10;
  defaultConfig = {
    type: `custom:${O}`,
    title: "",
    static: !1,
    show_entity_map: !1,
    battery_capacity_kwh: 21.31,
    battery_negative_is_charging: !0,
    entities: {}
  };
  static getStubConfig() {
    return { type: `custom:${O}` };
  }
}
customElements.get(O) || customElements.define(O, tt);
ye({
  tag: O,
  name: "JKS Detailed",
  description: "Redesigned full Jinko energy topology card."
});
const R = "jks-mini";
class at extends he {
  variant = "summary";
  defaultCardSize = 5;
  defaultConfig = {
    type: `custom:${R}`,
    title: "",
    static: !1,
    show_entity_map: !1,
    battery_capacity_kwh: 21.31,
    battery_negative_is_charging: !0,
    entities: {}
  };
  static getStubConfig() {
    return { type: `custom:${R}` };
  }
}
customElements.get(R) || customElements.define(R, at);
ye({
  tag: R,
  name: "JKS Mini",
  description: "Redesigned summary Jinko energy card."
});
